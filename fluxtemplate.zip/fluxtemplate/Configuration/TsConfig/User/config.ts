# do not hide newly created pages
TCAdefaults.pages.hidden = 0

# give nice alternating colors to the list module
mod.web_list.alternateBgColors = 1

# do not hide newly created news
TCAdefaults.tt_news.hidden = 0


admPanel {
	enable.edit = 1

	# Force re-loading the cache for external TS
	override.tsdebug.forceTemplateParsing = 1
}


options {

	# RTE
	RTESmallHeight = 500
	RTESmallWidth = 800

	clearCache{
		pages	= 1
		all		= 1
		system	= 1
	}

	saveDocNew = 1
	
	saveDocNew{
		tt_content	= 1
		pages		= 1
	}

	# Makes sure the clipboard doesn't clear:
	saveClipboard = 0

	# Reduces the amount of clipboards from 4 to 1:
	clipboardNumberPads = 1
	
	# show id withing page title
	pageTree {

		# show id withing page title
		showPageIdWithTitle		= 1
		
		# page tree option
		showDomainNameWithTitle	= 1

		# show nav title instead of title in the BE Page Tree
		showNavTitle			= 1

		onlineWorkspaceInfo		= 1
	}
}

### Not hide copied elements and let Title unchanged ###

TCEMAIN.table.tt_content {
	disablePrependAtCopy	= 1
	disableHideAtCopy		= 1
}