
# Include Powermail TypoScript
<INCLUDE_TYPOSCRIPT: source="FILE: EXT:fluxtemplate/Configuration/TypoScript/Extensions/powermail.ts">