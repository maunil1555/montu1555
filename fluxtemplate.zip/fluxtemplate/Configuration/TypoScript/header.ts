page.headTag = <head><meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /><link rel="icon" href="{$config.favicon}" type="image/ico; charset=binary"><script src="//use.fontawesome.com/74fa033f60.js"></script>

page.includeCSS {
    
    #fontawesome	= {$filepaths.css}font-awesome.css
    #popup       	= {$filepaths.css}magnific-popup.css     

     bootstrap	= {$filepaths.css}bootstrap.min.css	 
	 main 		= {$filepaths.css}main.css
     lightbox	= {$filepaths.css}lightbox.css
     developer	= {$filepaths.css}developer.css
	 gridTeam	= {$filepaths.css}gridTeam/grid.css
	 flex		= {$filepaths.css}flexslider/flexslider.css
     owl		= {$filepaths.css}owl/owl.css
     product	= {$filepaths.css}product_list_detail/product_list_detail.css

	
	animate		= {$filepaths.css}animate/animate.css
    #responsive	= {$filepaths.css}easy-responsive-tabs.css
    #material	= {$filepaths.css}materialdesignicons.min.css
    #web			= {$filepaths.css}web.css
    #logo_grid	= {$filepaths.css}logo_grid.css
    #print		= {$filepaths.css}print.css
    #print.media = print
    
    googlefont	= https://fonts.googleapis.com/css?family=Noto+Sans|Noto+Serif
    googlefont.external = 1
}

page.includeJSFooterlibs {

	bootstrap		= {$filepaths.js}bootstrap.min.js
	lightbox 		= {$filepaths.js}lightbox.js
	portfolio  		= {$filepaths.js}portfolio/portfolio.js	
	gridTeam		= {$filepaths.js}gridTeam/teamGrid.js
	flex			= {$filepaths.js}flexslider/flexslider.js
	owl				= {$filepaths.js}owl/owl.js
	product			= {$filepaths.js}product_list_detail/product_list_detail.js
	
	commonjs		= {$filepaths.js}common.js
	developer	    = {$filepaths.js}developer.js
	#carouseljs		= {$filepaths.js}owl.carousel.js
	
	#responsivejs	= {$filepaths.js}easy-responsive-tabs.js
	#webjs			= {$filepaths.js}web.js
	#xgallerify		= {$filepaths.js}jquery.xgallerify.js
	#readmore		= {$filepaths.js}readmore.min.js

}


[globalVar = TSFE:id = 47]
page.includeCSS {    
     bootstrap	=  
	 main 		= 
     lightbox	= 
     developer	= 
	 gridTeam	=
	 flex		= 
     owl		= 
     product	= 
	animate		= 
	 man2	   = {$filepaths.css}fce.css    
}

[globalVar = TSFE:id = 32]
page.includeCSS {    
     bootstrap	=  
	 main 		= 
     lightbox	= 
     developer	= 
	 gridTeam	=
	 flex		= 
     owl		= 
     product	= 
	animate		= 
	 man2	   = {$filepaths.css}fce.css    
}

[globalVar = TSFE:id = 31]
page.includeCSS {    
     bootstrap	=  
	 main 		= 
     lightbox	= 
     developer	= 
	 gridTeam	=
	 flex		= 
     owl		= 
     product	= 
	animate		= 
	 man2	   = {$filepaths.css}fce.css    
}

page.includeJSFooterlibs {

	bootstrap		= 
	lightbox 		= 
	portfolio  		= 
	gridTeam		= 
	flex			= 
	owl				= 
	product			= 
	
	commonjs		= 
	developer	    = {$filepaths.js}fce.js
	fceJS			

}

[end]



page.includeJS {
	#modernizr		= {$filepaths.js}modernizr.custom.26633.js
	jquery 			= {$filepaths.js}jquery.min1.11.3.js

	[browser = msie] && [version < 9]
		page.includeJSlibs {
			html5shiv	= https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js
			html5shiv.external = 1
			respond		= https://oss.maxcdn.com/respond/1.4.2/respond.min.js
			respond.external = 1
		}
	[end]
}



#page.headerData.9800 = TEXT  
#page.headerData.9800{
#	value (
#		<!-- Google Website Optimizer Control Script -->
#		
#		<script>
#			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
#			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
#			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
#			})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
#
#			ga('create', '{$config.trackingID}', 'auto');
#			ga('send', 'pageview');
#
#		</script>
#
#		<!-- End of Google Website Optimizer Control Script -->
#	)
#}


[globalVar = TSFE:id = 1]
	page.headerData.9898 = TEXT  
	page.headerData.9898{
		value (
			<script>
				jQuery(document).ready(function(){
				jQuery('ul.nav > li:first-child').addClass('active');
				})
			</script>
			)
	}
[end]


