# Powermail custom Typoscript
/*
plugin.tx_powermail {

	# Powermail Custom Template Path
	view {
		templateRootPaths {
			1 = {$filepaths.extensionsView}Powermail/Private/Templates/
		}
		partialRootPaths {
			1 = {$filepaths.extensionsView}Powermail/Private/Partials/
		}
		layoutRootPaths {
		   1 = {$filepaths.extensionsView}Powermail/Private/Layouts/
		}

		# Path to template root (FE)
		#templateRootPath = {$filepaths.extensionsView}Powermail/Private/Templates/
		
		# Path to template partials (FE)
		#partialRootPath = {$filepaths.extensionsView}Powermail/Private/Partials/
		
		# Path to template layouts (FE)
		#layoutRootPath = {$filepaths.extensionsView}Powermail/Private/Layouts/
	}
	settings{
		setup{
			cuur_id= 10
		}
	}
}
*/
/*
plugin.tx_powermail {
	view {
		templateRootPaths >
		templateRootPaths {
			0 = EXT:powermail/Resources/Private/Templates/
			1 = EXT:fluxtemplate/Resources/Private/Templates/Extensions/Powermail/Private/Templates/
		}
		partialRootPaths >
		partialRootPaths {
			0 = EXT:powermail/Resources/Private/Partials/
			1 = EXT:fluxtemplate/Resources/Private/Templates/Extensions/Powermail/Private/Partials/
		}
		layoutRootPaths >
		layoutRootPaths {
			0 = EXT:powermail/Resources/Private/Layouts/
			1 = EXT:fluxtemplate/Resources/Private/Templates/Extensions/Powermail/Private/Layouts/
		}
	}
}

*/

plugin.tx_powermail.settings.misc.addQueryString = 1
plugin.tx_powermail.settings.main.confirmation = 0
plugin.tx_powermail.settings.main.optin = 0
plugin.tx_powermail.settings.main.moresteps = 0
plugin.tx_powermail.settings.javascript.addAdditionalJavaScript = 0
plugin.tx_powermail.settings.javascript.powermailJQuery = 

plugin.tx_powermail.view.templateRootPath = EXT:fluxtemplate/Resources/Private/Templates/Extensions/Powermail/Private/Templates/
plugin.tx_powermail.view.partialRootPath = EXT:fluxtemplate/Resources/Private/Templates/Extensions/Powermail/Private/Partials/
plugin.tx_powermail.view.layoutRootPath = EXT:fluxtemplate/Resources/Private/Templates/Extensions/Powermail/Private/Layouts/

plugin.tx_powermail.settings.setup.spamshield.indicator.honeypod = 0


plugin.tx_powermail.settings.setup { 
	prefill { 
		coursetitle < lib.test123
	} 
}