###
# TEMPLATE: root_systemConfiguration
# DESCRIPTION: The CONFIGURATION ROOT template. This template will be called by the MASTER ROOT template. It reads the templates for changes in tt_content, lib.stdHeader etc.
###

tt_content {	
	# Make some modifications to the rendering of the standard MAIL form records
	#mailform.20 {
		#accessibility = 1
	#}
	
	# Remove the ancient onfocus="blurLink(this);" from sitemap links
	# Unfortunately this hasn't been fully implemented in css_styled_content yet
	# See also bug 11367
	menu.20 {
		default.1.noBlur = 1
		1.1.noBlur = 1
		4.1.noBlur = 1
		5.1.noBlur = 1
		6.1.noBlur = 1
		7.1.noBlur = 1
		7.2.noBlur = 1
	}

	# With this we can use - <link page-id> tag </link>
	html.parseFunc.tags.link < lib.parseFunc.tags.link
}

# replace strong in place of bold tag..

lib.parseFunc_RTE.tags{

	b=TEXT
	b{
		current=1
		wrap= <strong>|</strong>
	}
}

# For LightBox Settings to add rel=lightbox[lb15] to ancher<a> tag

tt_content.image.20.1.imageLinkWrap {

	JSwindow = 0
	directImageLink = 1
	typolink.ATagParams {
	dataWrap = rel="lightbox[lb{field:uid}]"
	if.negate = 1
	if.isTrue = TEXT
	}
	typolink.ATagParams.if.isTrue.field = image_link
	typolink.ATagParams.if.isTrue.listNum < .typolink.parameter.listNum
}


tt_content.text.20.wrap = <div class="contentArea">|</div>
tt_content.text.21.wrap = <div class="contentArea">|</div>

tt_content.stdWrap.innerWrap >

tt_content.image.20.renderMethod = figure
tt_content.image.20.rendering.figure
lib.parseFunc_RTE.nonTypoTagStdWrap.encapsLines.addAttributes.P.class >
lib.stdheader.stdWrap.dataWrap >
lib.stdheader.3.headerClass >
tt_content.stdWrap.dataWrap >

tt_content.stdWrap.innerWrap.cObject = CASE
tt_content.stdWrap.innerWrap.cObject {

	key.field = section_frame
	
	50 = TEXT
	50.value = <div class="csc-space-before-{field:spaceBefore} csc-space-after-{field:spaceAfter}"><div class="container"><div class="row">|</div></div></div>
} 


# Add class to All Table start
lib.parseFunc_RTE {
    externalBlocks {
        table.stdWrap.HTMLparser.tags.table.fixAttrib.class {
            default = table table-responsive table-bordered table-striped
            always = 1
            list >
        }
 table.stdWrap.wrap = <div class="table-responsive">|</div>
        
 }
}
# Add class to All Table end