#
# TEMPLATE: config
# DESCRIPTION: The PAGE CONFIG template. Only page.config settings are done here, like character sets, url and language. 
#

config {

	htmlTag_setParams = dir="ltr" class="no-js" xml:lang="de" lang="de"

	doctype = html5

	admPanel    		= {$config.adminPanel}
	debug      			= {$config.debug}
	
	doctype = html5
	# to get MSIE working in "standardsmode"
	xmlprologue = none

	inlineStyle2TempFile = 1

	pageTitleFirst = 1

	tx_realurl_enable = {$config.realURL}

	simulateStaticDocuments = 0

	index_enable = 1
	index_externals = 1

	pageTitleFirst = 1

	no_cache = 1
	prefixLocalAnchors= cached
	sys_language_overlay = hideNonTranslated
	#sys_language_overlay = content_fallback
	
	# set the defaultcharset
	renderCharset = utf-8
	metaCharset = utf-8
	
	notification_email_charset = utf-8
	xhtml_cleaning = 1
	linkVars = L
	
	sys_language_uid = 0
	
	uniqueLinkVars 		= 1
	language           	= de
	locale_all         	= de_DE
	htmlTag_langKey    	= de
	htmlTag_dir = ltr

	// Protect mail addresses from spamming
	spamProtectEmailAddresses = -3
	spamProtectEmailAddresses_atSubst = (at)
	spamProtectEmailAddresses_lastDotSubst = .

	# Disable the border attribute in images
	disableImgBorderAttr = 1
	removeGenerator = 1
	disablePrefixComment = 1
	
	sourceopt.enabled = 1
	sourceopt.removeBlurScript = 1
	sourceopt.removeGenerator = 1

	contentObjectExceptionHandler = 0

	// Comment in the <head> tag
	headerComment ( 
		
	)

	intTarget >
    extTarget = _blank

	
	#concatenateJs = 1
	#concatenateCss = 1

	#compressJs = 1
	#compressCss = 1
	
	pageNotFound_handling    = 1
	removeDefaultJS         = external
    inlineStyle2TempFile    = 1
	
}

[globalVar= GP:L=1]

	config {
		htmlTag_setParams = dir="ltr" class="no-js" xml:lang="en" lang="en"
		sys_language_uid	= 1
		language			= en
		htmlTag_langKey		= en
		locale_all			= en_US.UTF-8		
		# language_alt = de
	}

[global] 


// set body class to inner page
[globalVar = TSFE:id > 1]
	page.bodyTag = <body class="inner"> 
[end]
// add active class on Home page.



// Set baseURL setting for http or https

config.baseURL = http://{$config.baseURL}/

[globalString = IENV:TYPO3_SITE_URL=https://{$config.baseURL}/]
	config.baseURL = https://{$config.baseURL}/
[global]

// Condition to switch the doctype and xml prologue
[browser = msie]
	config.doctypeSwitch = 1
[global]


config.sourceopt {
	enabled = 1	
	enable_utf-8_support = 1
	formatHtml = 2
	formatHtml {
		tabSize =
		debugComment = 0
	}
}

plugin.tx_indexedsearch._DEFAULT_PI_VARS.lang = 0

page.meta.keywords.data = levelfield : -1 , keywords , slide
page.meta.description.data = levelfield : -1 , description , slide