
##############################
####   MAIN MENU  ####
##############################

lib.mainMenu = COA
lib.mainMenu{
	
	10= HMENU
	10.special = directory
	10.special.value = {$config.pid.mainMenu}
	10.1 = TMENU
	10.1 {
		wrap = <ul class="nav navbar-nav navbar-right">|</ul>
		noBlur = 1
		expAll = 1
		IFSUB = 1  
		ACTIFSUB = 1
		CUR = 1
	
		NO {
			wrapItemAndSub.insertData=1
			wrapItemAndSub = <li id="menu_{field:uid}" >|</li>
			ATagTitle.field = 1
		}

		ACT = 1
		ACT{
			wrapItemAndSub.insertData=1
			wrapItemAndSub =  <li id="menu_{field:uid}" class="active">|</li>
			ATagTitle.field = 1
			#stdWrap.htmlSpecialChars = 1
			ATagParams = class="active"
		}
	
		IFSUB{
			wrapItemAndSub.insertData=1
			wrapItemAndSub = <li id="menu_{field:uid}" class="dropdown">|</li>
			ATagTitle.field = 1
			ATagParams = 
		}

		ACTIFSUB {
			wrapItemAndSub.insertData=1
			wrapItemAndSub = <li id="menu_{field:uid}" class="dropdown active">|</li>
			#ATagTitle.field = 1
			ATagParams = 
		}
	}

	10.2  = TMENU
	10.2 {
		wrap = <span class="dropdown-toggle mobile-down" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="caret"></span></span><ul class="dropdown-menu">|</ul>
		noBlur = 1
		expAll = 1
		IFSUB = 1  
		
		NO {
			wrapItemAndSub.insertData = 1
			wrapItemAndSub = <li id="menu_{field:uid}" >|</li>
			ATagTitle.field = 1
			ATagParams = class=""
			stdWrap.htmlSpecialChars = 1
		}
		
		ACT = 1
		ACT{
			wrapItemAndSub.insertData = 1
			wrapItemAndSub = <li id="menu_{field:uid}" >|</li>
			ATagTitle.field = 1
			ATagParams = class="active"
		}
	}
}

##############################
####   FOOTER MENU  ####
##############################

lib.footerMenu = COA
lib.footerMenu {
	10 = HMENU
	10 {
	   special = directory
	   special.value = {$config.pid.footerMenu}
		1 = TMENU
		1 {
			wrap = <ul class="list-unstyled list-inline">|</ul>
			expAll = 1
			noBlur = 1
			NO = 1
		   # NO.ATagParams = target="_blank"
			NO {
				ATagTitle.field = abstract // description // title			   
				wrapItemAndSub = <li>|</li>
			}
			ACT < .NO
			ACT {
				wrapItemAndSub = <li class="active">|</li>
			}
			CUR < .ACT
		}	   
	}
}

