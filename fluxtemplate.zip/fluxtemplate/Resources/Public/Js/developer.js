jQuery(document).ready(function ($) {	
	//preloader();       
});

function preloader(){
	$("#preloader").fadeOut("slow", function() {
            $(this).remove()
    });
}





