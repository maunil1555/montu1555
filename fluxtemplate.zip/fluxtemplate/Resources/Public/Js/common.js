$(document).ready(function () {
	removeContainer();
	tableSet();
	removeBlankTags();
	callMagnificPopup();
	googleMapZoomEnable();	
	callLightbox();
	//callCarousel()
});

function callCarousel(){
  $('#quote-carousel').carousel({
    pause: true,
    interval: false,
  });
}

function removeBlankTags(){
	$('p, h2, h3, h4').map(function() {
		if( /^[\s ]*$/.test($(this).text()) ) {
		$(this).remove();
		}    
	});
}

function callMagnificPopup(){
	
	$(".popup , .lightbox, .magnificpopup").magnificPopup({
		  type: "image",
		  tLoading: "Loading image #%curr%...",
		  closeOnContentClick: true,
		  closeBtnInside: true,
		  fixedContentPos: true, 
		  mainClass: "mfp-no-margins mfp-with-zoom",
		  image: {
			  verticalFit: true,
			  tError: '<a href="%url%">The image</a> could not be loaded.'
		  },
		  zoom: {
			  enabled: true,
			  duration: 300
		  },
		});
		
	$(".singlePopup").magnificPopup({
		  type: "image",
		  tLoading: "Loading image #%curr%...",
		  closeOnContentClick: true,
		  closeBtnInside: true,
		  fixedContentPos: true, 
		  mainClass: "mfp-no-margins mfp-with-zoom",
		  image: {
			  verticalFit: true,
			  tError: '<a href="%url%">The image</a> could not be loaded.'
		  },
		  zoom: {
			  enabled: true,
			  duration: 300
		  },
	});
		
	$(".popup-gallery").each(function() {
		$(this).magnificPopup({
		  delegate: 'a',
		  type: "image",
		  tLoading: "Loading image #%curr%...",
		  closeOnContentClick: true,
		  closeBtnInside: true,
		  fixedContentPos: true, 
		  mainClass: "mfp-no-margins mfp-with-zoom",
		  image: {
			  verticalFit: true,
			  tError: '<a href="%url%">The image</a> could not be loaded.'
		  },
		  zoom: {
			  enabled: true,
			  duration: 300
		  },
		  gallery: {
			  enabled: true,
			  navigateByImgClick: true,
			  preload: [ 0, 1 ],
			  tCounter: '%curr% von %total%',
			  tPrev: 'Previous (Left arrow key)',
			  tNext: 'Next (Right arrow key)',
		  }
		});	
	});
	  
	$(".csc-textpic-imagecolumn").addClass("img-gallery");
	$(".csc-textpic .table caption").each(function() {
		var a = jQuery(this).text();
		$(this).closest(".popup").removeAttr("title");
		$(this).closest(".popup").attr("title", "+a+");
	});
	
 	$('.popup-video').magnificPopup({
        disableOn: 700,
        type: 'iframe',
        mainClass: 'mfp-fade',
        removalDelay: 160,
        preloader: false,
        fixedContentPos: true
    });

}

function googleMapZoomEnable(){
	$(".map-frame-box").click(function(){
	   $(this).removeClass("disabled");		
	   $( ".alert-success" ).fadeOut( "slow", function() {
			$("div").remove(".alert-success");
		});	
	});
}

function callLightbox(){
	lightbox.option({
        'resizeDuration': 200,
        'wrapAround': false,
        'disableScrolling' : true,
        "albumLabel" : "Build %1 vor %2"
    });
}

function tableSet(){
    $('.main section .container .row .ce-table').wrap('<div class="table-responsive clearfix"></div>');
    $(".table-responsive table").removeClass('ce-table');
    $(".table-responsive table").addClass('table table-responsive table-bordered table-striped');
}

function removeContainer(){
	 $('section .container , section .container-fluid').each(function() {
        $(this).find('.container').removeClass('container');   
		$(this).find('.container-fluid').removeClass('container');   		
    });		
}