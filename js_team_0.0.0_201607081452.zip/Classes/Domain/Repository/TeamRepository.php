<?php
namespace JS\JsTeam\Domain\Repository;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Jainish Senjailya <j>
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Teams
 */
class TeamRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{

    /**
     * @param $uid
     * @param $settings
     */
    public function team($uid, $settings)
    {
        $GLOBALS['TSFE']->set_no_cache();
        if ($settings['pid'] != '') {
            $where .= ' AND t.pid = ' . $settings['pid'];
        }
        if ($uid > 0) {
            if ($GLOBALS['TSFE']->sys_language_uid > 0) {
                $where = ' AND t.l10n_parent = ' . $uid;
            } else {
                $where = ' AND t.uid = ' . $uid;
            }
        }
        $where .= ' AND t.sys_language_uid = ' . $GLOBALS['TSFE']->sys_language_uid;
        if ($GLOBALS['TSFE']->sys_language_uid > 0) {
            $field2 = ' , t.l10n_parent as detail';
            $id = 'l10n_parent';
        } else {
            $field2 = ' , t.uid as detail';
            $id = 'uid';
        }
        $field1 = $field2 . ' , GROUP_CONCAT( concat( \'cat_\', c.'.$id.' ) SEPARATOR \' \' ) AS catClass ';
        $field = 't.*,GROUP_CONCAT(c.category SEPARATOR \', \' ) as cat_title, GROUP_CONCAT(c.uid) as categoryID ' . $field1;
        $table = 'tx_jsteam_domain_model_team AS t 

						LEFT JOIN tx_jsteam_team_category_mm AS m ON m.uid_local = t.uid 
						LEFT JOIN tx_jsteam_domain_model_category AS c ON m.uid_foreign = c.' . $id;
        $groupBy = ' t.uid ';
        $orderBy = ' t.uid desc';
        $teams = $this->getDBHandle()->exec_SELECTgetRows($field, $table, 't.deleted = 0 AND t.hidden = 0 ' . $where, $groupBy, $orderBy);
      //  echo $this->getDBHandle()->SELECTquery($field, $table, 't.deleted = 0 AND t.hidden = 0 ' . $where,$groupBy,$orderBy);	die;
        return $this->FalImage($teams, 'tx_jsteam_domain_model_team');
    }
    
    /**
     * @param $settings
     */
    function getCategory()
    {
        if ($GLOBALS['TSFE']->sys_language_uid > 0) {
            $field1 = ' , GROUP_CONCAT( concat( \'cat_\', l10n_parent ) SEPARATOR \' \' ) AS catClass ';
        } else {
            $field1 = ' , GROUP_CONCAT( concat( \'cat_\', uid ) SEPARATOR \' \' ) AS catClass ';
        }
        $field = '*' . $field1;
        $table = 'tx_jsteam_domain_model_category';
        $where = ' hidden = 0 AND deleted = 0 AND sys_language_uid = ' . $GLOBALS['TSFE']->sys_language_uid;
        $groupBy = ' uid ';
        if ($settings['pid'] != '') {
            $where .= ' AND pid = ' . $settings['pid'];
        }
        return $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy);
    }
    
    /**
     * FalImage
     *
     * @param $result
     * @param $tablename
     * @param $fieldname
     * @return
     */
    public function FalImage($result, $tablename = NULL, $fieldname = NULL)
    {
        // $query = $this->createQuery();
        // $query->getQuerySettings()->setReturnRawQueryResult(TRUE);
        $where = '';
        if ($tablename != '') {
            $where = ' AND tablenames = "' . $tablename . '"';
        }
        if ($fieldname != '') {
            $where .= ' AND fieldname IN ("' . $fieldname . '")';
        }
        foreach ($result as $key => $value) {
            $whr = ' deleted= 0 and hidden = 0 ' . $where . ' AND uid_foreign = ' . $value['uid'];
            $sysImages = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('*', 'sys_file_reference', $whr, '', 'sorting_foreign ASC', '');
            $arr = '';
            foreach ($sysImages as $key1 => $value1) {
                $fields1 = '*';
                $table1 = 'sys_file';
                $where1 = 'uid = ' . $value1['uid_local'];
                $groupBy1 = $orderBy1 = $limit1 = '';
                $sysImageDetail = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows($fields1, $table1, $where1, $groupBy1, $orderBy1, $limit1);
                // $sysImageDetail = 'SELECT * FROM sys_file WHERE uid = ' . $value1['uid_local'];
                // $query->statement($sysImageDetail);
                // $sysImageDetail = $query->execute();
                $arr[$value1['fieldname']][$value1['uid']]['identifier'] = 'fileadmin' . $sysImageDetail[0]['identifier'];
                $arr[$value1['fieldname']][$value1['uid']]['title'] = $value1['title'];
                $arr[$value1['fieldname']][$value1['uid']]['caption'] = $value1['description'];
                $arr[$value1['fieldname']][$value1['uid']]['extension'] = $sysImageDetail[0]['extension'];
                $arr[$value1['fieldname']][$value1['uid']]['mime_type'] = $sysImageDetail[0]['mime_type'];
                $arr[$value1['fieldname']][$value1['uid']]['name'] = $sysImageDetail[0]['name'];
                $arr[$value1['fieldname']][$value1['uid']]['uid'] = $sysImageDetail[0]['uid'];
                $arr1 = \TYPO3\CMS\Core\Utility\GeneralUtility::trimExplode('/', $sysImageDetail[0]['mime_type'], true);
                $arr[$value1['fieldname']][$value1['uid']]['mime'] = $arr1[0];
                $arr[$value1['fieldname']][$value1['uid']]['type'] = $arr1[1];
                $arr[$value1['fieldname']][$value1['uid']]['imageName'] = basename($sysImageDetail[0]['identifier']);
            }
            $result[$key]['media'] = $arr;
        }
        return $result;
    }
    
    /**
     * getDBHandle
     *
     * @return
     */
    public function getDBHandle()
    {
        return $GLOBALS['TYPO3_DB'];
    }

}