<?php

/***************************************************************
 * Extension Manager/Repository config file for ext "voucher".
 *
 * Auto generated 20-03-2015 08:39
 *
 * Manual updates:
 * Only the data in the array - everything else is removed by next
 * writing. "version" and "dependencies" must not be touched!
 ***************************************************************/

$EM_CONF[$_EXTKEY] = array (
	'title' => 'Voucher',
	'description' => 'This is extension for manage vouchers in Hotel.',
	'category' => 'plugin',
	'author' => 'Martin, Pooja',
	'author_email' => 'martin.galler@weboffice.co.at, pooja.patel@webofficeindia.com',
	'author_company' => 'Weboffice, Weboffice',
	'state' => 'stable',
	'uploadfolder' => '1',
	'createDirs' => '',
	'clearCacheOnLoad' => 0,
	'version' => '',
	'constraints' => 
	array (
		'depends' => 
		array (
			'extbase' => '1.3',
			'fluid' => '1.3',
			'typo3' => '6.0.0 - 6.2.99',
		),
		'conflicts' => 
		array (
		),
		'suggests' => 
		array (
		),
	),
);

