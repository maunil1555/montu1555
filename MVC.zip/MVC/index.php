<?php

header("Location: http://localhost/MVC/view/view.php");
?>