<?php

//include("view/view.php");
include("../controller/controller.php");

?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<title>phptaab.blogspot.in</title>

</head>

<body>

<table border="1" align="center" cellspacing="9" cellpadding="5">
	<tr>
		<td colspan="4"><a href="add_product.php">Add Product </a></td>
		<td><a type="button" class="btn btn-primary pull-right delete_all">Delete selected</a></td>
	</tr>
	<tr>
		<td><input type="checkbox" id="master"></td>
		<td>ID</td>
		<td>Product name</td>
		<td>Product image</td>
		<td>Action</td>
	</tr>
			<?php 
			
			while($row = $product_data->fetch_assoc()){ ?>
			<tr>
				<td>
				<input type="checkbox" name="" class="sub_chk"  data-id="<?php echo $row['id']; ?>" >

				</td>
				<td><?php echo $row['id']; ?></td>
				<td><?php echo $row['name']; ?></td>
				<td><?php echo $row['images']; ?></td>
				<td><a href="javascript:void(0);" class="remove_row" id="<?php echo $row['id']; ?>" > Delete </a> | <a href="index.php?upd_id=<?php echo $row['id']; ?>"> Update </a></td>
			</tr>
		<?php } ?>
</table>

</body>

<script type="text/javascript">
$(document).ready(function(){
	jQuery('#master').on('click', function(e) {
		if($(this).is(':checked',true))  
		{
			$(".sub_chk").prop('checked', true);  
		}  
		else  
		{  
			$(".sub_chk").prop('checked',false);  
		}  
	});
	
	
  	$('a.delete_all').click(function(){
		var allVals = [];  
		$(".sub_chk:checked").each(function() {  
			allVals.push($(this).attr('data-id'));
		});  
		//alert(allVals.length); return false;  
		if(allVals.length <=0)  
		{  
			alert("Please select row.");  
		}  
		else {  
			//$("#loading").show(); 
			WRN_PROFILE_DELETE = "Are you sure you want to delete this row?";  
			var check = confirm(WRN_PROFILE_DELETE);  
			if(check == true){  
				//for server side
				var join_selected_values = allVals.join(","); 
				$.ajax({   
					type: "GET",  
					url: "view.php",  
					cache:false,  
					data: 'ids='+join_selected_values,
					success: function(response)  
					{   
						var emp_ids = join_selected_values.split(","); 
						for (var i=0; i < emp_ids.length; i++ ) {
							$("a#"+emp_ids[i]).parents("tr").remove(); 
						} 
					}   
				});
			}  
		}  
	});
	
	$('a.remove_row').click(function(){
		var delete_a = $(this);
		var single_id = $(this).attr('id');
		WRN_PROFILE_DELETE = "Are you sure you want to delete this row?";  
			var check = confirm(WRN_PROFILE_DELETE);  
			if(check == true){
					$.ajax({   
						type: "GET",  
						url: "view.php",  
						cache:false,  
						data: 'ids='+single_id,
						success: function(response)  
						{   
							console.log(response);
							$(delete_a).parents('tr').remove();
						}   
					});				            
			}
	});
});
</script>

</html>