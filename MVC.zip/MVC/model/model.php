<?php

//error_reporting(0);

include("../database/config.php");
class Model extends db{
	
	private $conn; 
	public function __construct() { 
       
       $this->conn = $this->connect();
    }
	public function insert($tabl,$data) {

			$keys = array_keys($data);
			$keys = implode(',', $keys);
			//$keys = "'$keys'";

			$value = array_values($data);
			$value = implode("','", $value);
			$value = "'$value'";
			$query = "INSERT INTO `product`($keys) VALUES ($value)";
			
			$succ = $this->conn->query($query);
			//$succ = mysql_query($query);

			if($succ){
				echo "successfully inserted";
			}
	}
	public function select($table){

		$query = "SELECT * FROM $table";
		
		$categories = $this->conn->query($query);
		//$categories = mysql_query($query);
		
		return $categories;

	}
	public function select_where($table,$data){

		 $query = "SELECT * FROM $table WHERE id IN ($data)";
			
		//$select_images = mysql_query($query);
		$select_images = $this->conn->query($query);
		while ($row = $select_images->fetch_assoc()) {
			
			$res_img = $row['images'];
			
		}
		return $res_img;
	}
	public function delete($table,$data){

		$query = "DELETE FROM $table WHERE id IN ($data)";		
		$deleted = $this->conn->query($query);
		//$deleted = mysql_query($query);
		return 1;

	}
	
}



?>