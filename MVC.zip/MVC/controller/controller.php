<?php
/*
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);*/
include("../model/model.php");
	$obj = new Model;
	if(isset($_POST['submit'])){
		$name 	= $_POST['product_name'];
		$image 	= $_FILES['image']['name'];
		$cat	= $_POST['category'];	
		//$image = implode(',', $image);
		$target_dir = "../upload/";
		$uploadOk = 1;
		$target_file = $target_dir . basename($_FILES["image"]["name"]);
		$fname = pathinfo($target_file, PATHINFO_FILENAME);
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
		$time = time();
		$final_image = $fname.$time.'.'.$imageFileType;
	    $check = getimagesize($_FILES["image"]["tmp_name"]);
	    if($check !== false) {
	        echo "File is an image - " . $check["mime"] . ".";
	        $uploadOk = 1;
	    } else {
	        echo "File is not an image.";
	        $uploadOk = 0;
	    }
	    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_dir .$final_image)) {
	        echo "The file ". $final_image. " has been uploaded.";
	    }   
		$data = array('name' => $name,'images' => $final_image,'cat_id' => $cat );
		$ins = $obj->insert('product',$data);
	}
	$categories = $obj->select('category');
	if(isset($_GET['ids'])){
		$data = $_GET['ids'];
		$deleted_success = $obj->select_where('product',$data);
		$success = unlink('../upload'.'/'.$deleted_success);			
		echo $deleted_success = $obj->delete('product',$data);  die();
	}
	$product_data = $obj->select('product');
?>