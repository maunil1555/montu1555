<?php
namespace Maunil\Newsletter\Domain\Repository;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Maunil <montu1555@gmail.com>, Worlds technologies
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Newsletters
 */
use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \Maunil\Newsletter\Service\MailTemplate;
use \Maunil\Newsletter\Service\HtmlTags;
class NewsletterRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{
	public function findemail($useremail,$settings,$getmethodsData,$actionUrl,$footerContentForEmail){

			/*echo "<pre>";
			print_r($settings);
			die;		*/	

			$to 			= $useremail['email'];
			$fromEmail 			= $settings['senderEmail'];
			$subject 		= $settings['senderSubject'];
			$mailName 		= $settings['senderName'];
			$userMessage	= $settings['userMessage'];
			//for Admin mail
  			$admin_mail		= $settings['receiverEmail'];
			$from_admin 		= $settings['receiverEmail'];
			$subject_admin 	= $settings['receiverSubject'];
			$mailName_admin 	= $settings['receiverName'];
			$email_message 	= $settings['adminMessage'];

			
			
			$fields = '*';
			$table = 'tt_address';

			$insertfield = array('email' => $useremail['email'],'pid' => $settings['storageFolder'],'hidden' => $useremail['hidden'],'module_sys_dmail_html' => $useremail['module_sys_dmail_html']);

			$Admin_message = $settings['adminMessage'].'<a style="color: rgb(212, 226, 27);" href="'.$useremail['email'].'">'.$useremail['email'].'</a></br>'.$footerContentForEmail;
		
			$where = 'deleted = 0 and pid = '.$settings['storageFolder'].' AND email = "'.$useremail['email'].'" ';
			
			$res = $GLOBALS['TYPO3_DB']->exec_SELECTquery($fields,$table,$where);
			/*echo "<pre>";
			print_r($res);
			die;		*/
			$numofraws = $GLOBALS['TYPO3_DB']->sql_num_rows($res); 
			//$numofraws = count($res);
			
					if($numofraws == 0){	
						//echo $in = $GLOBALS['TYPO3_DB']->INSERTQuery($table,$insertfield); die;
						$insert = $GLOBALS['TYPO3_DB']->exec_INSERTquery($table,$insertfield);
						$lastInsertId = $GLOBALS['TYPO3_DB']->sql_insert_id();								

						if($insert){
							
							if($settings['sendToReceiver'] == 1) {
								$from = array($from_admin => $mailName_admin);
								$sendToReceiver = $this->sendEmails($admin_mail,$from,$subject_admin,$Admin_message, $settings, 0); // mail to Receiver	
							}
							$approveUrl = $actionUrl.'?subscribeID='.base64_encode($lastInsertId)."&act=1";

							$sub = '<a style="color: rgb(212, 226, 27);" href="'.$approveUrl.'">Confirm subscription</a>';

							$approveUrls = '<a style="color: rgb(212, 226, 27);" href="'.$approveUrl.'">'.$approveUrl.'</a>';

							$userMessage = str_replace("###Subscription_url###", $approveUrls, $userMessage);

							$userMessage = str_replace("###confirm_subscription###", $sub, $userMessage);

							$mailcontent = $userMessage."<br>".$footerContentForEmail;

        					//$deleteUrl = $actionUrl.'?del=1&subscribeID='.base64_encode($getRecord[0]['uid']);

        					$from = array($fromEmail => $mailName);

							$sendEmails = $this->sendEmails($to,$from,$subject,$mailcontent,$settings, 0);
							if($sendEmails){
								return 1;
								
							}
						}	
					}else{

						$resultDATA = $GLOBALS['TYPO3_DB']->exec_SELECTgetSingleRow($fields,$table,$where);
						
						if($resultDATA['hidden'] == 1){

							$approveUrl = $actionUrl.'?subscribeID='.base64_encode($resultDATA['uid'])."&act=1";

							$sub = '<a style="color: rgb(212, 226, 27);" href="'.$approveUrl.'">Confirm subscription</a>';

							$approveUrls = '<a style="color: rgb(212, 226, 27);" href="'.$approveUrl.'">'.$approveUrl.'</a>'; 


							$userMessage = str_replace("###confirm_subscription###", $sub, $userMessage);

							$userMessage = str_replace("###Subscription_url###", $approveUrls, $userMessage);
							

							$mailcontent = $userMessage."<br>".$footerContentForEmail;

        					//$deleteUrl = $actionUrl.'?del=1&subscribeID='.base64_encode($getRecord[0]['uid']);

        					$from = array($fromEmail => $mailName);

							$sendEmails = $this->sendEmails($to,$from,$subject,$mailcontent,$settings, 0);
							if($sendEmails){
								return 1;
								header("Location:".$actionUrl);
							}
						}
						//return -2;
						//header("Location:".$actionUrl);
					}
	}

	public function changeStatus($uid,$settings,$useremail,$actionUrl, $content){


		$table = 'tt_address';
		$where = 'uid  = '.$uid;
	
		$res = $GLOBALS['TYPO3_DB']->exec_SELECTgetSingleRow('*',$table,$where);
		
		if($res['hidden'] == 1){

				$updateArr = array(
					'hidden'	=> 0,
				);

				$update = $GLOBALS['TYPO3_DB']->exec_UPDATEquery($table,'uid='.$uid,$updateArr);

					if($update){
						
						//$mailcontent = "Thank you for subscription we will get back to you soon";
						$mailcontent = $content;
						
						$from = array($settings['senderEmail'] =>  $settings['senderName']);

						$confirmEmails = $this->sendEmails($res['email'],$from,$settings['senderConfirmSubject'],$mailcontent,$settings); // mail to User
						//$confirmEmails = $this->sendEmails($to,$from,$subject,$userMessage,$mailName);
						if($confirmEmails){
							return 4;
							header("Location:".$actionUrl); 
						}
					}

		}else{
			return 6;
		}
	}
	public function unsubscribeEmail($settings,$unsubemail,$actionUrl,$footerContentForEmail){
		$fields = '*';
		$table = 'tt_address';
		//$where = "";
		$where = 'pid = '.$settings['storageFolder'].' AND email = "'.$unsubemail.'" ';
		//echo $res1 = $GLOBALS['TYPO3_DB']->SELECTquery($fields,$table,$where); die;
		$res1 = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows($fields,$table,$where);
		

		if($res1[0]['email'] == $unsubemail){
			
					
			$user_unsub_Confirm_msg = $settings['userunsubscribeConfirmMail'];
			
			$unsubUrl = $actionUrl.'?unsubscribeID='.base64_encode($res1[0]['uid'])."&act=1";

			$unsub = '<a style="color: rgb(212, 226, 27);" href="'.$unsubUrl.'">Confirm Unsubscription</a>';

			$unsub_approveUrls = '<a style="color: rgb(212, 226, 27);" href="'.$unsubUrl.'">'.$unsubUrl.'</a>';

			$user_unsub_Confirm_msg = str_replace("###Unsubscription_url###", $unsub_approveUrls, $user_unsub_Confirm_msg);

			$user_unsub_Confirm_msg = str_replace("###confirm_unsubscription###", $unsub, $user_unsub_Confirm_msg);

			$mailcontent2 = $user_unsub_Confirm_msg."<br>".$footerContentForEmail;

			
			$table = 'tt_address';
			$wheredel = 'deleted = 0 and pid = '.$settings['storageFolder'].' AND email = "'.$unsubemail.'" ';
			
			$res = $GLOBALS['TYPO3_DB']->exec_SELECTgetSingleRow('*',$table,$wheredel);
			

			$from = array($settings['senderEmail'] =>  $settings['senderName']);
			
			$unsubscribeEmails = $this->sendEmails($res['email'],$from,$settings['senderunsubscribeSubject'],$mailcontent2,$settings);					
			
			if($unsubscribeEmails){
				return 143;
			}

			//$del = $GLOBALS['TYPO3_DB']->exec_DELETEquery($table,$wheredel);
			
			/*if($del){
				//$mailcontent1 = "You are successfully unsubscribe our newsletter</br>".$footerContentForEmail;
				$mailcontent1 = $settings['userunsubscribeMessage'].'</br>'.$footerContentForEmail;

				$from = array($settings['senderEmail'] =>  $settings['senderName']);

				$unsubscribeEmails = $this->sendEmails($res['email'],$from,$settings['senderunsubscribeSubject'],$mailcontent1,$settings);

				if($unsubscribeEmails){
					return -3;
					header("Location:".$actionUrl);
				}
			}*/
		}else{
			return 5;
		}

	}
	public function deleteEmail($unsub_id,$settings,$footerContentForEmail){


		$table = 'tt_address';
		$wheredel = ' uid = '.$unsub_id;


		$res = $GLOBALS['TYPO3_DB']->exec_SELECTgetSingleRow('*',$table,$wheredel);
		//echo  $del = $GLOBALS['TYPO3_DB']->DELETEquery($table,$wheredel); die;
		
		if($res['deleted'] == 0){
		

				$updateArr = array(
					'deleted'	=> 1,
				);
				//echo $update = $GLOBALS['TYPO3_DB']->UPDATEquery($table,$wheredel,$updateArr); die;
				$update = $GLOBALS['TYPO3_DB']->exec_UPDATEquery($table,$wheredel,$updateArr);
				if($update){
					$mailcontent1 = $settings['userunsubscribeMessage'].'</br>'.$footerContentForEmail;

					$from = array($settings['senderEmail'] =>  $settings['senderName']);

					$unsubscribeEmails = $this->sendEmails($res['email'],$from,$settings['senderunsubscribeSubject'],$mailcontent1,$settings);

					if($unsubscribeEmails){
						return -3;
					}
				}
		}else{
			return 144;
		}
		
	}
	function sendEmails($recipient,$from = array(),$subject,$mailcontent, $settings = array(), $bccEmail = 1){

		$html = '<!doctype html>
				<html lang="en">
					<head>
						<meta charset="utf-8">
						<title>Weboffice</title>
						<meta name="description" content="Weboffice">
						<meta name="author" content="Weboofice">
						<style> a {color:rgb(212, 226, 27) !important;} </style>
						</head>
						<body>
							'.$mailcontent.'
						</body>
				</html>';

		$mail = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Mail\\MailMessage');

		if(count($from)>0){
			$mail->setFrom($from);
		}
		$mail->setTo($recipient);
		$mail->setSubject($subject);

		// BCC
		if ($bccEmail==1) {
			if (trim($settings['bccEmail']) && GeneralUtility::validEmail($settings['bccEmail'])) {
				if (trim($settings['bccName'])) {
					$mail->setBcc(array($settings['bccEmail'] => $settings['bccName']));
				} else {
					$mail->setReplyTo(array($settings['bccEmail']));
				}
			}
		}

		if (trim($settings['replyToEmail']) && GeneralUtility::validEmail($settings['replyToEmail'])) {
			if (trim($settings['replyToName'])) {
				$mail->setReplyTo(array($settings['replyToEmail'] => $settings['replyToName']));
			} else {
				$mail->setReplyTo(array($settings['replyToEmail']));
			}
		}

		$mail->setBody($mailcontent, 'text/html');
		return $mail->send();
	}
}