<?php
namespace Maunil\Newsletter\Controller;

session_start();

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Maunil <montu1555@gmail.com>, Worlds technologies
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * NewsletterController
 */
class NewsletterController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * newsletterRepository
     *
     * @var \Maunil\Newsletter\Domain\Repository\NewsletterRepository
     * @inject
     */
    protected $newsletterRepository = NULL;
    
    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {

        //$newsletters = $this->newsletterRepository->findAll();

        $message = '';

        if(isset($_SESSION['contactMessage'])){
            $message = $_SESSION['contactMessage'];
            unset($_SESSION['contactMessage']);
        }


        $emailView = $this->objectManager->get('TYPO3\\CMS\\Fluid\\View\\StandaloneView');

        $templateName = 'Email/footer.html';

        $extbaseFrameworkConfiguration = $this->configurationManager->getConfiguration(\TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FRAMEWORK);

        $templateRootPath = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($extbaseFrameworkConfiguration['view']['templateRootPaths'][0]);
        $templatePathAndFilename = $templateRootPath.$templateName;
        
        
        $emailView->setTemplatePathAndFilename($templatePathAndFilename);
        $footerContentForEmail = $emailView->render(); 

       

        $GLOBALS["TSFE"]->set_no_cache();

        $actionUrl = $this->request->getBaseUri(); //$this->uriBuilder->getRequest()->getRequestUri(); 
        $getmethodsData = $_GET;
        $settings = $this->settings;
        $admin_mail     = $settings['receiverEmail'];
        if($admin_mail == ""){
            $_SESSION['contactMessage'] = 149;
            header("Location:".$actionUrl); die;
        }
        $useremail = $_POST;
            
         /*   echo "<pre>";
            print_r($settings);
            die;*/
        

        if(isset($_REQUEST['unsubscribeID'])){
           
           $unsub_id = intVal(base64_decode($_GET['unsubscribeID']));


            if($unsub_id>0){
            
                $_SESSION['contactMessage'] = $this->newsletterRepository->deleteEmail($unsub_id,$settings,$footerContentForEmail);
                header("Location:".$actionUrl); die;
            }
        }

        if (isset($_GET['subscribeID'])) {
            
            $sid = intVal(base64_decode($_GET['subscribeID']));
            
            if($sid>0){

                $pageUid = 1;
                $additionalParams = array("actionurl"=>"unsubscribe");
                $unsubscribeURL = $actionUrl.$this->uriBuilder->reset()->setTargetPageUid($pageUid)->setArguments($additionalParams)->buildFrontendUri();

                $unsubscribeURL = str_replace("//", "/", $unsubscribeURL);

                $msg = $settings['usersuccessMessage'];

                $unsubscribeURL = '<a style="color: rgb(212, 226, 27);" href="'.$unsubscribeURL.'">'.$unsubscribeURL.'</a>';

                $msg = str_replace("###unsubscription_url###", $unsubscribeURL, $msg);
               
                $content = $msg.$footerContentForEmail; 

                $_SESSION['contactMessage'] = $this->newsletterRepository->changeStatus($sid,$settings,$useremail,$actionUrl,$content);
                header("Location:".$actionUrl); die;
            }
        }else if(isset($_GET['actionurl']) && $_GET['actionurl']=="unsubscribe" && !empty($_POST['email'])) {
       
            $unsubemail = $_POST['email'];

            $_SESSION['contactMessage'] = $this->newsletterRepository->unsubscribeEmail($settings,$unsubemail,$actionUrl,$footerContentForEmail);
            header("Location:".$actionUrl); die;

        }else if(isset($_POST['submit'])){
       
            $_SESSION['contactMessage'] = $this->newsletterRepository->findemail($useremail,$settings,$getmethodsData,$actionUrl,$footerContentForEmail);
            header("Location:".$actionUrl); die;
           
        } 
         
        $this->view->assign('message', $message);
        $this->view->assign('settings', $settings);
        $this->view->assign('actionUrl', $actionUrl);
        $this->view->assign('getmethodsData', $getmethodsData);
    }

}