<?php

//error_reporting(0);

include("../database/config.php");
class Model extends db{
	
	private $conn; 
	public function __construct() { 
       
       $this->conn = $this->connect();
    }
	public function insert($tabl,$data) {

			$keys = array_keys($data);
			$keys = implode(',', $keys);
			//$keys = "'$keys'";

			$value = array_values($data);
			$value = implode("','", $value);
			$value = "'$value'";
			$query = "INSERT INTO `$tabl`($keys) VALUES ($value)";
			
			$succ = $this->conn->query($query);
			//$succ = mysql_query($query);

			if($succ){
				echo "successfully inserted";
			}
	}
	public function select($table){

		$query = "SELECT * FROM $table";
		
		$categories = $this->conn->query($query);
		//$categories = mysql_query($query);
		
		return $categories;

	}
	public function select_where($table,$data){

		 $query = "SELECT * FROM $table WHERE id IN ($data)";
			
		//$select_images = mysql_query($query);
		$select_images = $this->conn->query($query);
		while ($row = $select_images->fetch_assoc()) {
			
			$res_img = $row['images'];
			
		}
		return $res_img;
	}
	public function delete($table,$data){

		$query = "DELETE FROM $table WHERE id IN ($data)";		
		$deleted = $this->conn->query($query);
		//$deleted = mysql_query($query);
		return 1;

	}
	public function check_user($table,$data){
		$username = $data['username'];
		$email = $data['email'];
		$user_check_query = "SELECT * FROM users WHERE username='$username' OR email='$email' LIMIT 1";
		$result = $this->conn->query($user_check_query);
		return $user = mysqli_fetch_assoc($result);

	}
	public function register_user($tabl,$data){
			
			$keys = array_keys($data);
			$keys = implode(',', $keys);
			//$keys = "'$keys'";
			$value = array_values($data);
			$value = implode("','", $value);
			$value = "'$value'";
			$query = "INSERT INTO `$tabl`($keys) VALUES ($value)";
			$succ = $this->conn->query($query);
			//$succ = mysql_query($query);
			if($succ){
				echo "successfully inserted";
				$_SESSION['username'] = $data['username'];
				$_SESSION['success'] = "You are now logged in";
				header('location: view.php');
			}
	
	}
	public function login_user($table,$data){
		$username = $data['username'];
		$password = $data['password'];
		
		$query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
		$results = $this->conn->query($query);
		if (mysqli_num_rows($results) == 1) {
		  $_SESSION['username'] = $username;
		  $_SESSION['success'] = "You are now logged in";
		  header('location: view.php');
		}else {
			echo "Wrong username/password combination"; die;
		}
	}
	
}



?>