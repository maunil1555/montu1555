<!DOCTYPE html>
<?php
session_start(); 
if (!isset($_SESSION['username'])) {
	$_SESSION['msg'] = "You must log in first";
	header('location: login.php');
}
if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['username']);
	header("location: login.php");
}
include("../controller/controller.php");

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title></title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>

<body>

<form method="post" action="" enctype="multipart/form-data" >
<table border="1" align="center" cellspacing="9" cellpadding="5">
	
	<tr>
		<td><a href="../index.php">View Product</a> </td>
		<td><a href="add_category.php">Add Category </a></td>
	</tr>
	<tr>
		<td>Product name</td>
		<td><input type="text" name="product_name" class="form-control"/></td>
	</tr>
	<tr>
		<td>Images</td>
		<td><input type="file" name="image" class="form-control" multiple="multiple" /></td>
	</tr>
	<tr>
		<td>Category</td>
		<td>
			<select name="category">
			<?php
			
			while ($row = mysqli_fetch_array($categories,MYSQL_ASSOC)) {
			
		

			?>		
				  <option value="<?php echo $row['id']; ?>"> <?php echo $row['name']; ?> </option>
				  
				  
			<?php
			}
			?>
			</select>
		</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="submit" value="Add product" class="btn btn-success btn-lg"/></td>
	</tr>
</table>

</form>
</body>
</html>