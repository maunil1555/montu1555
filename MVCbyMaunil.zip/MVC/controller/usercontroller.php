<?php

include("../model/model.php");
$obj = new Model;
session_start();
if (isset($_POST['reg_user'])) {
  // receive all input values from the form
  $username = $_POST['username'];
  $email =  $_POST['email'];
  $password_1 = $_POST['password_1'];
  $password_2 = $_POST['password_2'];

  if (empty($username)) {
	  echo "Username is required"; die;
	}
  if (empty($email)) { echo "Email is required"; die;}
  if (empty($password_1)) { echo "Password is required"; die; }
  if ($password_1 != $password_2) {
	echo "The two passwords do not match"; die;
  }
  $data = array('username' => $username,'email' => $email);
  $user = $obj->check_user('users',$data);
  
  if ($user) { // if user exists
    if ($user['username'] === $username) {
      echo "Username already exists"; die;
    }
    if ($user['email'] === $email) {
      echo  "email already exists"; die;
    }
	$password = md5($password_1);//encrypt the password before saving in the database
	$data = array('username' => $username,'email' => $email,'password' => $password );
	$user = $obj->register_user('users',$data);
  }
  
}
if (isset($_POST['login_user'])) {
	$username =  $_POST['username'];
	$password =  $_POST['password'];
	$password = md5($password);
	$data = array('username' => $username,'password' => $password );
	if (empty($username)) {
		echo "Username is required"; die;
	}
	if (empty($password)) {
		echo "Password is required"; die;
	}
	$login_user = $obj->login_user('users',$data);
}
?>