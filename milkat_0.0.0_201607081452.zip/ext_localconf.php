<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
	'Maunil.' . $_EXTKEY,
	'Milkat',
	array(
		'Milkat' => 'list, show',
		'Category' => 'list, show',
		'Registration' => 'list, show',
		'Location' => 'list, show',
		'Amenities' => 'list, show',
		
	),
	// non-cacheable actions
	array(
		'Milkat' => '',
		'Category' => '',
		'Registration' => '',
		'Location' => '',
		'Amenities' => '',
		
	)
);


