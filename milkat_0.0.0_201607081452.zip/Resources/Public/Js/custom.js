

	$().ready(function() {
		// validate the comment form when it is submitted
		//$("#registraionForm").validate();

		// validate signup form on keyup and submit
		$("#registraionForm").validate({
			rules: {
				name: {
					required: true,
					minlength: 2
				},
				password: {
					required: true,
					minlength: 5
				},
				cmfpassword: {
					required: true,
					minlength: 5,
					equalTo: "#password"
				},
				email: {
					required: true,
					email: true
				},
				mobile: {
					required: true,
					minlength: 2
				} 
			},
			messages: {
				name: {
					required: "Please enter a name",
					minlength: "Your name must consist of at least 2 characters"
				},
				password: {
					required: "Please provide a password",
					minlength: "Your password must be at least 5 characters long"
				},
				cmfpassword: {
					required: "Please provide a password",
					minlength: "Your password must be at least 5 characters long",
					equalTo: "Please enter the same password as above"
				},
				email: "Please enter a valid email address"
			}
		});
		$("#postproperty").validate({
			rules: {
				propertyname: {
					required: true,
					minlength: 5
				},
				property_address: {
					required: true,
					minlength: 15
				},
				short_description: {
					required: true,
					minlength: 15
				},
				full_description: {
					required: true,
					minlength: 20
				},
				price: {
					required: true
				},
				ownership: {
					required: true,
					minlength: 5
				},
				possession_from: {
					required: true,
					minlength: 5
				},
				built_area: {
					required: true,
					minlength: 5
				},
				property_facing: {
					required: true,
					minlength: 5
				},
				category: {
					required: true
				},
				location: {
					required: true

				},
				amenities: {
					required: true
				}
			},
			messages: {
				propertyname: {
					required: "Please enter a property name",
					minlength: "Property name must consist of at least 5 characters"
				},
				property_address: {
					required: "Please provide a property address",
					minlength: "Property address must be at least 15 characters long"
				},
				short_description: {
					required: "Please provide a short_description",
					minlength: "Short description must be at least 15 characters long"
					
				},
				full_description: {
					required: "Please provide a full_description",
					minlength: "Full description must be at least 20 characters long"
				},
				price: {
					required: "Please provide price"
				},
				ownership: {
					required: "Please provide ownership",
					minlength: "Ownership must be at least 5 characters long"
				},
				possession_from: {
					required: "Please provide possession_from",
					minlength: "Possession from must be at least 5 characters long"
				},
				built_area: {
					required: "Please provide built_area",
					minlength: "Built area must be at least 5 characters long"
				},
				property_facing: {
					required: "Please provide property_facing",
					minlength: "Property facing must be at least 5 characters long"
				},
				category: {
					required: "Please provide category"
				},
				location: {
					required: "Please provide location"
				},
				amenities: {
					required: "Please provide amenities"
					
				}
			}
		});

	});

	function showPassword() {
    
    var key_attr = $('#key').attr('type');
    
    if(key_attr != 'text') {
        
        $('.checkbox').addClass('show');
        $('#key').attr('type', 'text');
        
    } else {
        
        $('.checkbox').removeClass('show');
        $('#key').attr('type', 'password');
        
    }
    
}