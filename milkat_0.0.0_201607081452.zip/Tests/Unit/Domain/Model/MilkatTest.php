<?php

namespace Maunil\Milkat\Tests\Unit\Domain\Model;

/***************************************************************
 *  Copyright notice
 *
 *  (c) 2016 maunil <montu1555@gmail.com>, woi
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class \Maunil\Milkat\Domain\Model\Milkat.
 *
 * @copyright Copyright belongs to the respective authors
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 *
 * @author maunil <montu1555@gmail.com>
 */
class MilkatTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
	/**
	 * @var \Maunil\Milkat\Domain\Model\Milkat
	 */
	protected $subject = NULL;

	public function setUp()
	{
		$this->subject = new \Maunil\Milkat\Domain\Model\Milkat();
	}

	public function tearDown()
	{
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function getMilkatnameReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getMilkatname()
		);
	}

	/**
	 * @test
	 */
	public function setMilkatnameForStringSetsMilkatname()
	{
		$this->subject->setMilkatname('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'milkatname',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getPropertyAddressReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getPropertyAddress()
		);
	}

	/**
	 * @test
	 */
	public function setPropertyAddressForStringSetsPropertyAddress()
	{
		$this->subject->setPropertyAddress('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'propertyAddress',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getShortDescriptionReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getShortDescription()
		);
	}

	/**
	 * @test
	 */
	public function setShortDescriptionForStringSetsShortDescription()
	{
		$this->subject->setShortDescription('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'shortDescription',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getFullDescriptionReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getFullDescription()
		);
	}

	/**
	 * @test
	 */
	public function setFullDescriptionForStringSetsFullDescription()
	{
		$this->subject->setFullDescription('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'fullDescription',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getPriceReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getPrice()
		);
	}

	/**
	 * @test
	 */
	public function setPriceForStringSetsPrice()
	{
		$this->subject->setPrice('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'price',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getImageReturnsInitialValueForFileReference()
	{
		$this->assertEquals(
			NULL,
			$this->subject->getImage()
		);
	}

	/**
	 * @test
	 */
	public function setImageForFileReferenceSetsImage()
	{
		$fileReferenceFixture = new \TYPO3\CMS\Extbase\Domain\Model\FileReference();
		$this->subject->setImage($fileReferenceFixture);

		$this->assertAttributeEquals(
			$fileReferenceFixture,
			'image',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getOwnershipReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getOwnership()
		);
	}

	/**
	 * @test
	 */
	public function setOwnershipForStringSetsOwnership()
	{
		$this->subject->setOwnership('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'ownership',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getPossessionFromReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getPossessionFrom()
		);
	}

	/**
	 * @test
	 */
	public function setPossessionFromForStringSetsPossessionFrom()
	{
		$this->subject->setPossessionFrom('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'possessionFrom',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getBuiltAreaReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getBuiltArea()
		);
	}

	/**
	 * @test
	 */
	public function setBuiltAreaForStringSetsBuiltArea()
	{
		$this->subject->setBuiltArea('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'builtArea',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getPropertyFacingReturnsInitialValueForString()
	{
		$this->assertSame(
			'',
			$this->subject->getPropertyFacing()
		);
	}

	/**
	 * @test
	 */
	public function setPropertyFacingForStringSetsPropertyFacing()
	{
		$this->subject->setPropertyFacing('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'propertyFacing',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getCategoryReturnsInitialValueForCategory()
	{
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getCategory()
		);
	}

	/**
	 * @test
	 */
	public function setCategoryForObjectStorageContainingCategorySetsCategory()
	{
		$category = new \Maunil\Milkat\Domain\Model\Category();
		$objectStorageHoldingExactlyOneCategory = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneCategory->attach($category);
		$this->subject->setCategory($objectStorageHoldingExactlyOneCategory);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneCategory,
			'category',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addCategoryToObjectStorageHoldingCategory()
	{
		$category = new \Maunil\Milkat\Domain\Model\Category();
		$categoryObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$categoryObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($category));
		$this->inject($this->subject, 'category', $categoryObjectStorageMock);

		$this->subject->addCategory($category);
	}

	/**
	 * @test
	 */
	public function removeCategoryFromObjectStorageHoldingCategory()
	{
		$category = new \Maunil\Milkat\Domain\Model\Category();
		$categoryObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$categoryObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($category));
		$this->inject($this->subject, 'category', $categoryObjectStorageMock);

		$this->subject->removeCategory($category);

	}

	/**
	 * @test
	 */
	public function getLocationReturnsInitialValueForLocation()
	{
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getLocation()
		);
	}

	/**
	 * @test
	 */
	public function setLocationForObjectStorageContainingLocationSetsLocation()
	{
		$location = new \Maunil\Milkat\Domain\Model\Location();
		$objectStorageHoldingExactlyOneLocation = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneLocation->attach($location);
		$this->subject->setLocation($objectStorageHoldingExactlyOneLocation);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneLocation,
			'location',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addLocationToObjectStorageHoldingLocation()
	{
		$location = new \Maunil\Milkat\Domain\Model\Location();
		$locationObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$locationObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($location));
		$this->inject($this->subject, 'location', $locationObjectStorageMock);

		$this->subject->addLocation($location);
	}

	/**
	 * @test
	 */
	public function removeLocationFromObjectStorageHoldingLocation()
	{
		$location = new \Maunil\Milkat\Domain\Model\Location();
		$locationObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$locationObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($location));
		$this->inject($this->subject, 'location', $locationObjectStorageMock);

		$this->subject->removeLocation($location);

	}

	/**
	 * @test
	 */
	public function getAmenitiesReturnsInitialValueForAmenities()
	{
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getAmenities()
		);
	}

	/**
	 * @test
	 */
	public function setAmenitiesForObjectStorageContainingAmenitiesSetsAmenities()
	{
		$amenity = new \Maunil\Milkat\Domain\Model\Amenities();
		$objectStorageHoldingExactlyOneAmenities = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneAmenities->attach($amenity);
		$this->subject->setAmenities($objectStorageHoldingExactlyOneAmenities);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneAmenities,
			'amenities',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addAmenityToObjectStorageHoldingAmenities()
	{
		$amenity = new \Maunil\Milkat\Domain\Model\Amenities();
		$amenitiesObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$amenitiesObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($amenity));
		$this->inject($this->subject, 'amenities', $amenitiesObjectStorageMock);

		$this->subject->addAmenity($amenity);
	}

	/**
	 * @test
	 */
	public function removeAmenityFromObjectStorageHoldingAmenities()
	{
		$amenity = new \Maunil\Milkat\Domain\Model\Amenities();
		$amenitiesObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$amenitiesObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($amenity));
		$this->inject($this->subject, 'amenities', $amenitiesObjectStorageMock);

		$this->subject->removeAmenity($amenity);

	}
}
