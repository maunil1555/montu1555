<?php
namespace Maunil\Milkat\Controller;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 maunil <montu1555@gmail.com>, woi
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * RegistrationController
 */
class RegistrationController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * registrationRepository
     *
     * @var \Maunil\Milkat\Domain\Repository\RegistrationRepository
     * @inject
     */
    protected $registrationRepository = NULL;
    
    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $GLOBALS['TSFE']->set_no_cache();
        $actionUrl = $this->request->getBaseUri();
        //$this->uriBuilder->getRequest()->getRequestUri();
        $settings = $this->settings;
        $this->view->assign('settings', $settings);
        if (isset($_REQUEST['regi']) == 'reg') {
            $template = 'registration';
            $this->view->assign('registration', $template);
        }
        if (isset($_POST['regist'])) {
            $UserRegistration = $this->registrationRepository->UserRegistration($settings, $actionUrl);
            $this->view->assign('UserRegistration', $UserRegistration);
        }
        if (isset($_REQUEST['Login']) == 'Log') {
            $template = 'Login';
            $this->view->assign('Login', $template);
        }
        // if(isset($_REQUEST['logout'])){
        //    session_unset();
        //    session_destroy();
        // }
        if (isset($_REQUEST['login'])) {
            $checkLogin = $this->registrationRepository->checkLogin();
            if ($checkLogin == -1) {
                $this->redirect('show');
            }
            $this->view->assign('checkLogin', $checkLogin);
        }
        $property = $this->registrationRepository->getProperty();
        $this->view->assign('milkats', $property);
        $js = '<script>
        $(document).ready(function(){
            $(\'#example\').DataTable();
        });
        </script>';
        $this->view->assign('actionUrl', $actionUrl);
        $this->includeAdditionalData($js);
    }
    
    /**
     * action show
     *
     * @param \Maunil\Milkat\Domain\Model\Registration $registration
     * @return void
     */
    public function showAction(\Maunil\Milkat\Domain\Model\Registration $registration)
    {
        echo 'maunil';
        die;
        $GLOBALS['TSFE']->set_no_cache();
        $actionUrl = $this->request->getBaseUri();
        //$this->uriBuilder->getRequest()->getRequestUri();
        //$this->view->assign('registration', $registration);
        if (isset($_REQUEST['postproperty'])) {
            $postproperty = $this->registrationRepository->postproperty($settings, $actionUrl);
            $this->view->assign('postproperty', $postproperty);
        }
        $this->view->assign('actionUrl', $actionUrl);
        $this->includeAdditionalData($js);
    }
    
    /**
     * includeAdditionalData
     *
     * @param $js
     */
    function includeAdditionalData($js)
    {
        $additionalheaderData = '<link rel="stylesheet" type="text/css" href="typo3conf/ext/milkat/Resources/Public/Css/locate.css" media="all" /> 
                <link rel="stylesheet" href="typo3conf/ext/milkat/Resources/Public/Css/jquery.dataTables.css">';
        $additionalfooterData .= '<script src="https://maps.googleapis.com/maps/api/js?&libraries=geometry,places"></script>
                <!--<script type="text/javascript" src="typo3conf/ext/milkat/Resources/Public/Js/jquery-1.9.0.min.js"></script>-->
                <script type="text/javascript" src="typo3conf/ext/milkat/Resources/Public/Js/markerclusterer.js"></script>
                <script type="text/javascript" src="typo3conf/ext/milkat/Resources/Public/Js/bootstrap.js"></script>
                <script type="text/javascript" src="typo3conf/ext/milkat/Resources/Public/Js/locate.js" charset="utf-8"></script>
                <script type="text/javascript" src="typo3conf/ext/milkat/Resources/Public/Js/jquery-1.12.0.min.js" charset="utf-8"></script>
                <script type="text/javascript" src="typo3conf/ext/milkat/Resources/Public/Js/jquery.dataTables.js"></script>';
        $GLOBALS['TSFE']->additionalHeaderData['9669'] = $additionalheaderData;
        $GLOBALS['TSFE']->additionalFooterData['9996'] = $additionalfooterData;
    }

}