<?php
namespace Maunil\Milkat\Controller;
session_start();
/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 maunil <montu1555@gmail.com>, woi
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * MilkatController
 */
class MilkatController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * milkatRepository
     *
     * @var \Maunil\Milkat\Domain\Repository\MilkatRepository
     * @inject
     */
    protected $milkatRepository = NULL;
    
    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $GLOBALS['TSFE']->set_no_cache();
        //$actionUrl = $this->request->getBaseUri(); //$this->uriBuilder->getRequest()->getRequestUri(); 
        $settings = $this->settings; 
        $actionUrl = $this->uriBuilder->getRequest()->getRequestUri();
        if(isset($_REQUEST['registerID'])){
            $confirmid = $_REQUEST['registerID'];
            $confirmid  = base64_decode($confirmid);
            $ConfirmRegistration = $this->milkatRepository->ConfirmRegistration($settings,$actionUrl,$confirmid);           
            $this->view->assign('ConfirmRegistration', $ConfirmRegistration);
        }
        if (isset($_REQUEST['regi']) == 'reg') {
            $template = 'registration';
            $this->view->assign('registration', $template);
        }
        if (isset($_REQUEST['Login']) == 'Log') {
            $template = 'Login';
            $this->view->assign('Login', $template);
        }
        if (isset($_POST['regist'])) {

            $UserRegistration = $this->milkatRepository->UserRegistration($settings,$actionUrl);
            $this->view->assign('UserRegistration', $UserRegistration);
        }
        // echo "<pre>";
        // print_r($_POST);
        // die;
        if (isset($_REQUEST['login'])) {

            $checkLogin = $this->milkatRepository->checkLogin();
     
            if($checkLogin == -1){
                $this->view->assign('checkLogin', $checkLogin);
            }
            if($checkLogin == 2){
               
                $_SESSION['uid'];
                $this->redirect('show');   
            }
        }
        $property = $this->milkatRepository->getProperty($settings,$actionUrl,$uid,$getmethodsData);
        // die;
        // echo "<pre>";
        // print_r($property);
        $this->view->assign('milkats', $property);
        $js = '<script>
        $(document).ready(function(){
            $(\'#example\').DataTable();
        });
        </script>';
        //$milkats = $this->milkatRepository->findAll();
        //$this->view->assign('milkats', $milkats);
        $this->includeAdditionalData($js);
    }
    
    /**
     * action show
     *
     * 
     * @return void
     */
    public function showAction()
    {
        
        if(isset($_REQUEST['logout'])){
            session_unset();
            session_destroy();
            $this->redirect('list');   
        }
        $GLOBALS['TSFE']->set_no_cache();
        $actionUrl = $this->request->getBaseUri(); //$this->uriBuilder->getRequest()->getRequestUri(); 
        $settings = $this->settings; 
        // echo "<pre>";
        // print_r($uid);
        // die;
        $uid = $_SESSION['uid'];

        if(isset($_REQUEST['tx_milkat_milkat']['update_profile']) == 'user_profile' ){
            
            $update_pro = $this->milkatRepository->update_delete_profile($uid,$settings,$actionUrl);

            $this->view->assign('update_pro', $update_pro);
        }
        if($uid){
            $propertyForm = "propertyForm";
            $this->view->assign('propertyForm', $propertyForm);

            $getProfile = $this->milkatRepository->getProfile($settings,$actionUrl,$uid);
            $this->view->assign('getProfile', $getProfile);
            
            $getCategory = $this->milkatRepository->getCategory($settings,$actionUrl); 
            $this->view->assign('getCategory', $getCategory);
            $getLocation = $this->milkatRepository->getLocation($settings,$actionUrl); 
            $this->view->assign('getLocation', $getLocation);
            $getAmenities = $this->milkatRepository->getAmenities($settings,$actionUrl); 
            $this->view->assign('getAmenities', $getAmenities);
        }
        if(isset($_REQUEST['postproperty'])){
            $getmethodsData = $_GET;
            $postproperty = $this->milkatRepository->postproperty($settings,$actionUrl,$uid,$getmethodsData); 
            $this->view->assign('postproperty', $postproperty);
         }
       
        if(isset($_GET['tx_milkat_milkat']['milkat'])){
              $getmethodsData = $_GET;
              $property = $this->milkatRepository->getProperty($settings,$actionUrl,$uid,$getmethodsData);
                  if(is_array($property)){
                    $detail = "propertyDetails";
                    $this->view->assign('detail', $detail);
                  }
                
              $property = $property[0];
              $this->view->assign('milkats', $property);
        }
        if(isset($_GET['tx_milkat_milkat']['delete'])){
             $getmethodsData = $_GET;
            $deleted = $this->milkatRepository->update_deleteProperty($settings,$actionUrl,$getmethodsData); 
            $this->view->assign('postproperty', $deleted);
        }
        if(isset($_GET['tx_milkat_milkat']['update'])){
            $getmethodsData = $_GET;
            $selectedData = $this->milkatRepository->update_deleteProperty($settings,$actionUrl,$getmethodsData); 
            /*
            foreach($getCategory as $key=>$value){
                //$data[$value['uid']]['name'] = $value['categoryname'];
                $data[]= $value['categoryname'];
                
                //if (in_array($value['categoryname'], $selectedData['cat'])){
                   //$data[$value['uid']]['selected'] = 1;
                }
            }*/

            $this->view->assign('selectedData', $selectedData);
        }
        
        $property = $this->milkatRepository->getProperty($settings,$actionUrl,$uid,$getmethodsData);
        // echo "<pre>";
        // print_r($property);
        // die;
        $this->view->assign('milkats', $property);
        $this->view->assign('actionUrl', $actionUrl);
         $js = '<script>
        $(document).ready(function(){
            $(\'#example\').DataTable();
        });
        </script>';
        $this->includeAdditionalData($js);
    }
    
    /**
     * includeAdditionalData
     *
     * @param $js
     */
    function includeAdditionalData($js)
    {
        $additionalheaderData = '<link rel="stylesheet" href="typo3conf/ext/milkat/Resources/Public/Css/jquery.dataTables.css"><link rel="stylesheet" href="typo3conf/ext/milkat/Resources/Public/Css/milkat.css">';
        $additionalfooterData .= '<script type="text/javascript" src="typo3conf/ext/milkat/Resources/Public/Js/jquery-1.12.0.min.js" charset="utf-8"></script>
                <script type="text/javascript" src="typo3conf/ext/milkat/Resources/Public/Js/jquery.dataTables.js"></script><script type="text/javascript" src="typo3conf/ext/milkat/Resources/Public/Js/jquery.js"></script><script type="text/javascript" src="typo3conf/ext/milkat/Resources/Public/Js/jquery.validate.min.js"></script><script type="text/javascript" src="typo3conf/ext/milkat/Resources/Public/Js/custom.js" charset="utf-8"></script>'.$js;
        $GLOBALS['TSFE']->additionalHeaderData['9669'] = $additionalheaderData;
        $GLOBALS['TSFE']->additionalFooterData['9996'] = $additionalfooterData;
    }

}