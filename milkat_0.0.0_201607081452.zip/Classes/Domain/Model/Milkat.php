<?php
namespace Maunil\Milkat\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 maunil <montu1555@gmail.com>, woi
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Milkat
 */
class Milkat extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * milkatname
     *
     * @var string
     */
    protected $milkatname = '';
    
    /**
     * propertyAddress
     *
     * @var string
     */
    protected $propertyAddress = '';
    
    /**
     * shortDescription
     *
     * @var string
     */
    protected $shortDescription = '';
    
    /**
     * fullDescription
     *
     * @var string
     */
    protected $fullDescription = '';
    
    /**
     * price
     *
     * @var string
     */
    protected $price = '';
    
    /**
     * image
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    protected $image = null;
    
    /**
     * ownership
     *
     * @var string
     */
    protected $ownership = '';
    
    /**
     * possessionFrom
     *
     * @var string
     */
    protected $possessionFrom = '';
    
    /**
     * builtArea
     *
     * @var string
     */
    protected $builtArea = '';
    
    /**
     * propertyFacing
     *
     * @var string
     */
    protected $propertyFacing = '';
    
    /**
     * category
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Maunil\Milkat\Domain\Model\Category>
     */
    protected $category = null;
    
    /**
     * location
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Maunil\Milkat\Domain\Model\Location>
     */
    protected $location = null;
    
    /**
     * amenities
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Maunil\Milkat\Domain\Model\Amenities>
     */
    protected $amenities = null;
    
    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }
    
    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->category = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $this->location = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $this->amenities = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }
    
    /**
     * Returns the milkatname
     *
     * @return string $milkatname
     */
    public function getMilkatname()
    {
        return $this->milkatname;
    }
    
    /**
     * Sets the milkatname
     *
     * @param string $milkatname
     * @return void
     */
    public function setMilkatname($milkatname)
    {
        $this->milkatname = $milkatname;
    }
    
    /**
     * Returns the propertyAddress
     *
     * @return string $propertyAddress
     */
    public function getPropertyAddress()
    {
        return $this->propertyAddress;
    }
    
    /**
     * Sets the propertyAddress
     *
     * @param string $propertyAddress
     * @return void
     */
    public function setPropertyAddress($propertyAddress)
    {
        $this->propertyAddress = $propertyAddress;
    }
    
    /**
     * Returns the shortDescription
     *
     * @return string $shortDescription
     */
    public function getShortDescription()
    {
        return $this->shortDescription;
    }
    
    /**
     * Sets the shortDescription
     *
     * @param string $shortDescription
     * @return void
     */
    public function setShortDescription($shortDescription)
    {
        $this->shortDescription = $shortDescription;
    }
    
    /**
     * Returns the fullDescription
     *
     * @return string $fullDescription
     */
    public function getFullDescription()
    {
        return $this->fullDescription;
    }
    
    /**
     * Sets the fullDescription
     *
     * @param string $fullDescription
     * @return void
     */
    public function setFullDescription($fullDescription)
    {
        $this->fullDescription = $fullDescription;
    }
    
    /**
     * Returns the price
     *
     * @return string $price
     */
    public function getPrice()
    {
        return $this->price;
    }
    
    /**
     * Sets the price
     *
     * @param string $price
     * @return void
     */
    public function setPrice($price)
    {
        $this->price = $price;
    }
    
    /**
     * Returns the image
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
     */
    public function getImage()
    {
        return $this->image;
    }
    
    /**
     * Sets the image
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
     * @return void
     */
    public function setImage(\TYPO3\CMS\Extbase\Domain\Model\FileReference $image)
    {
        $this->image = $image;
    }
    
    /**
     * Returns the ownership
     *
     * @return string $ownership
     */
    public function getOwnership()
    {
        return $this->ownership;
    }
    
    /**
     * Sets the ownership
     *
     * @param string $ownership
     * @return void
     */
    public function setOwnership($ownership)
    {
        $this->ownership = $ownership;
    }
    
    /**
     * Returns the possessionFrom
     *
     * @return string $possessionFrom
     */
    public function getPossessionFrom()
    {
        return $this->possessionFrom;
    }
    
    /**
     * Sets the possessionFrom
     *
     * @param string $possessionFrom
     * @return void
     */
    public function setPossessionFrom($possessionFrom)
    {
        $this->possessionFrom = $possessionFrom;
    }
    
    /**
     * Returns the builtArea
     *
     * @return string $builtArea
     */
    public function getBuiltArea()
    {
        return $this->builtArea;
    }
    
    /**
     * Sets the builtArea
     *
     * @param string $builtArea
     * @return void
     */
    public function setBuiltArea($builtArea)
    {
        $this->builtArea = $builtArea;
    }
    
    /**
     * Returns the propertyFacing
     *
     * @return string $propertyFacing
     */
    public function getPropertyFacing()
    {
        return $this->propertyFacing;
    }
    
    /**
     * Sets the propertyFacing
     *
     * @param string $propertyFacing
     * @return void
     */
    public function setPropertyFacing($propertyFacing)
    {
        $this->propertyFacing = $propertyFacing;
    }
    
    /**
     * Adds a Category
     *
     * @param \Maunil\Milkat\Domain\Model\Category $category
     * @return void
     */
    public function addCategory(\Maunil\Milkat\Domain\Model\Category $category)
    {
        $this->category->attach($category);
    }
    
    /**
     * Removes a Category
     *
     * @param \Maunil\Milkat\Domain\Model\Category $categoryToRemove The Category to be removed
     * @return void
     */
    public function removeCategory(\Maunil\Milkat\Domain\Model\Category $categoryToRemove)
    {
        $this->category->detach($categoryToRemove);
    }
    
    /**
     * Returns the category
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Maunil\Milkat\Domain\Model\Category> $category
     */
    public function getCategory()
    {
        return $this->category;
    }
    
    /**
     * Sets the category
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Maunil\Milkat\Domain\Model\Category> $category
     * @return void
     */
    public function setCategory(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $category)
    {
        $this->category = $category;
    }
    
    /**
     * Adds a Location
     *
     * @param \Maunil\Milkat\Domain\Model\Location $location
     * @return void
     */
    public function addLocation(\Maunil\Milkat\Domain\Model\Location $location)
    {
        $this->location->attach($location);
    }
    
    /**
     * Removes a Location
     *
     * @param \Maunil\Milkat\Domain\Model\Location $locationToRemove The Location to be removed
     * @return void
     */
    public function removeLocation(\Maunil\Milkat\Domain\Model\Location $locationToRemove)
    {
        $this->location->detach($locationToRemove);
    }
    
    /**
     * Returns the location
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Maunil\Milkat\Domain\Model\Location> $location
     */
    public function getLocation()
    {
        return $this->location;
    }
    
    /**
     * Sets the location
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Maunil\Milkat\Domain\Model\Location> $location
     * @return void
     */
    public function setLocation(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $location)
    {
        $this->location = $location;
    }
    
    /**
     * Adds a Amenities
     *
     * @param \Maunil\Milkat\Domain\Model\Amenities $amenity
     * @return void
     */
    public function addAmenity(\Maunil\Milkat\Domain\Model\Amenities $amenity)
    {
        $this->amenities->attach($amenity);
    }
    
    /**
     * Removes a Amenities
     *
     * @param \Maunil\Milkat\Domain\Model\Amenities $amenityToRemove The Amenities to be removed
     * @return void
     */
    public function removeAmenity(\Maunil\Milkat\Domain\Model\Amenities $amenityToRemove)
    {
        $this->amenities->detach($amenityToRemove);
    }
    
    /**
     * Returns the amenities
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Maunil\Milkat\Domain\Model\Amenities> $amenities
     */
    public function getAmenities()
    {
        return $this->amenities;
    }
    
    /**
     * Sets the amenities
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Maunil\Milkat\Domain\Model\Amenities> $amenities
     * @return void
     */
    public function setAmenities(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $amenities)
    {
        $this->amenities = $amenities;
    }

}