<?php
namespace Maunil\Milkat\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 maunil <montu1555@gmail.com>, woi
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Registration
 */
class Registration extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * name
     *
     * @var string
     */
    protected $name = '';
    
    /**
     * email
     *
     * @var string
     */
    protected $email = '';
    
    /**
     * password
     *
     * @var string
     */
    protected $password = '';
    
    /**
     * gender
     *
     * @var string
     */
    protected $gender = '';
    
    /**
     * mobile
     *
     * @var string
     */
    protected $mobile = '';
    
    /**
     * profilePhoto
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    protected $profilePhoto = null;
    
    /**
     * milkat
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Maunil\Milkat\Domain\Model\Milkat>
     * @cascade remove
     */
    protected $milkat = null;
    
    /**
     * Returns the name
     *
     * @return string $name
     */
    public function getName()
    {
        return $this->name;
    }
    
    /**
     * Sets the name
     *
     * @param string $name
     * @return void
     */
    public function setName($name)
    {
        $this->name = $name;
    }
    
    /**
     * Returns the email
     *
     * @return string $email
     */
    public function getEmail()
    {
        return $this->email;
    }
    
    /**
     * Sets the email
     *
     * @param string $email
     * @return void
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }
    
    /**
     * Returns the password
     *
     * @return string $password
     */
    public function getPassword()
    {
        return $this->password;
    }
    
    /**
     * Sets the password
     *
     * @param string $password
     * @return void
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }
    
    /**
     * Returns the gender
     *
     * @return string $gender
     */
    public function getGender()
    {
        return $this->gender;
    }
    
    /**
     * Sets the gender
     *
     * @param string $gender
     * @return void
     */
    public function setGender($gender)
    {
        $this->gender = $gender;
    }
    
    /**
     * Returns the mobile
     *
     * @return string $mobile
     */
    public function getMobile()
    {
        return $this->mobile;
    }
    
    /**
     * Sets the mobile
     *
     * @param string $mobile
     * @return void
     */
    public function setMobile($mobile)
    {
        $this->mobile = $mobile;
    }
    
    /**
     * Returns the profilePhoto
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $profilePhoto
     */
    public function getProfilePhoto()
    {
        return $this->profilePhoto;
    }
    
    /**
     * Sets the profilePhoto
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $profilePhoto
     * @return void
     */
    public function setProfilePhoto(\TYPO3\CMS\Extbase\Domain\Model\FileReference $profilePhoto)
    {
        $this->profilePhoto = $profilePhoto;
    }
    
    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }
    
    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->milkat = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }
    
    /**
     * Adds a Milkat
     *
     * @param \Maunil\Milkat\Domain\Model\Milkat $milkat
     * @return void
     */
    public function addMilkat(\Maunil\Milkat\Domain\Model\Milkat $milkat)
    {
        $this->milkat->attach($milkat);
    }
    
    /**
     * Removes a Milkat
     *
     * @param \Maunil\Milkat\Domain\Model\Milkat $milkatToRemove The Milkat to be removed
     * @return void
     */
    public function removeMilkat(\Maunil\Milkat\Domain\Model\Milkat $milkatToRemove)
    {
        $this->milkat->detach($milkatToRemove);
    }
    
    /**
     * Returns the milkat
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Maunil\Milkat\Domain\Model\Milkat> $milkat
     */
    public function getMilkat()
    {
        return $this->milkat;
    }
    
    /**
     * Sets the milkat
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Maunil\Milkat\Domain\Model\Milkat> $milkat
     * @return void
     */
    public function setMilkat(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $milkat)
    {
        $this->milkat = $milkat;
    }

}