<?php
namespace Maunil\Milkat\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 maunil <montu1555@gmail.com>, woi
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Amenities
 */
class Amenities extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * aminitiesName
     *
     * @var string
     */
    protected $aminitiesName = false;
    
    /**
     * Returns the boolean state of parking
     *
     * @return bool
     */
    public function isParking()
    {
        return $this->parking;
    }
    
    /**
     * Returns the boolean state of reservedParking
     *
     * @return bool
     */
    public function isReservedParking()
    {
        return $this->reservedParking;
    }
    
    /**
     * Returns the boolean state of garden
     *
     * @return bool
     */
    public function isGarden()
    {
        return $this->garden;
    }
    
    /**
     * Returns the boolean state of gymnasium
     *
     * @return bool
     */
    public function isGymnasium()
    {
        return $this->gymnasium;
    }
    
    /**
     * Returns the boolean state of powerBackup
     *
     * @return bool
     */
    public function isPowerBackup()
    {
        return $this->powerBackup;
    }
    
    /**
     * Returns the boolean state of security
     *
     * @return bool
     */
    public function isSecurity()
    {
        return $this->security;
    }
    
    /**
     * Returns the boolean state of swimmingPool
     *
     * @return bool
     */
    public function isSwimmingPool()
    {
        return $this->swimmingPool;
    }
    
    /**
     * Returns the boolean state of lawn
     *
     * @return bool
     */
    public function isLawn()
    {
        return $this->lawn;
    }
    
    /**
     * Returns the boolean state of playArea
     *
     * @return bool
     */
    public function isPlayArea()
    {
        return $this->playArea;
    }
    
    /**
     * Returns the boolean state of rainWaterharvesting
     *
     * @return bool
     */
    public function isRainWaterharvesting()
    {
        return $this->rainWaterharvesting;
    }
    
    /**
     * Returns the boolean state of servantQuarters
     *
     * @return bool
     */
    public function isServantQuarters()
    {
        return $this->servantQuarters;
    }
    
    /**
     * Returns the aminitiesName
     *
     * @return string aminitiesName
     */
    public function getAminitiesName()
    {
        return $this->aminitiesName;
    }
    
    /**
     * Sets the aminitiesName
     *
     * @param bool $aminitiesName
     * @return void
     */
    public function setAminitiesName($aminitiesName)
    {
        $this->aminitiesName = $aminitiesName;
    }

}