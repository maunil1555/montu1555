<?php
namespace Maunil\Milkat\Domain\Repository;

session_start();
/***************************************************************
 *
 *	Copyright notice
 *
 *	(c) 2016 maunil <montu1555@gmail.com>, woi
 *
 *	All rights reserved
 *
 *	This script is part of the TYPO3 project. The TYPO3 project is
 *	free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	The GNU General Public License can be found at
 *	http://www.gnu.org/copyleft/gpl.html.
 *
 *	This script is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
 *	GNU General Public License for more details.
 *
 *	This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Milkats
 */
use \TYPO3\CMS\Core\Utility\GeneralUtility;
class MilkatRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{
		/**
		 * @param $settings
		 * @param $actionUrl
		 */
		public function UserRegistration($settings,$actionUrl)
		{
				if (isset($_POST['regist'])) {
					 
						if (isset($_POST['email'])) {
								$pid = $settings['storagePID'];
								$email = $_POST['email'];
								$fields = '*';
								$table = 'tx_milkat_domain_model_registration';
								$where = 'deleted = 0 AND hidden = 0 AND status = 0 AND email = "' . $_POST['email'] . '" ';
								$res = $GLOBALS['TYPO3_DB']->exec_SELECTquery($fields, $table, $where);
								$numofraws = $GLOBALS['TYPO3_DB']->sql_num_rows($res);
								if ($numofraws == 0) {

										$file['name']		= $_FILES['photo']['name'];
										$file['type']		= $_FILES['photo']['type'];
										$file['tmp_name']	= $_FILES['photo']['tmp_name'];
										$file['size']		= $_FILES['photo']['size']; 
									 
										$fields_values = array(
												'name' => $_POST['name'],
												'email' => $_POST['email'],
												'password' => $_POST['password'],
												'gender' => $_POST['gender'],
												'mobile' => $_POST['mobile'],
												'profile_photo' => $file['name'],
												'pid' => $pid
										);
										$table = 'tx_milkat_domain_model_registration';
										$where = 'hidden = 0 AND deleted = 0';


										$reg = $this->getDBHandle()->exec_INSERTquery($table, $fields_values, $no_quote_fields = false, $where);
										$lastInsertId = $GLOBALS['TYPO3_DB']->sql_insert_id();															 
										$getRecord = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows($fields,$table,'uid='.$lastInsertId);
	
										if ($reg) {
												$files = $this->uploadFile($file['name'], $file['type'], $file['tmp_name'], $file['size']);
												$to = $email;
												$from = $settings['flexform']['receiver']['email'];
												$mailName = $settings['flexform']['receiver']['name'];
												$subject =	$settings['flexform']['receiver']['subject'];
												$approveUrl = $actionUrl.'& registerID='.base64_encode($getRecord[0]['uid']); 

												$mailcontent = "<table><tr><td>Hello $to</td></tr><tr><td><a href='$approveUrl'>If you want to activate your subscription then click here</a></td></tr></table>";

												$sendEmails = $this->sendEmails($to,$from,$subject,$mailcontent,$mailName);
												return 1;
										}
								}
								if ($numofraws > 0) {
										return -2;
								}
						}
				}
		}
		/**
		 * @param $settings
		 * @param $actionUrl
		 * @param $confirmid
		 */
		public function ConfirmRegistration($settings,$actionUrl,$confirmid){
				//echo $confirmid;die;		
				$table = 'tx_milkat_domain_model_registration';
				$where = "uid = ".$confirmid;
				$updateArr = array('status' => 1,'uid' => $confirmid);
			 // echo $success = $this->getDBHandle()->UPDATEquery($table,$where,$updateArr); die;
				$success = $this->getDBHandle()->exec_UPDATEquery($table,$where,$updateArr);
				if($success){
						return 9;	 
				}
		}
		/**
		 * @param $uid
		 * @param $settings
		 * @param $actionUrl
		 */
		public function update_delete_profile($uid,$settings,$actionUrl){
				if(isset($_REQUEST['updet'])){
						 $pid	= $settings['storagePID'];
						$file['name']		= $_FILES['photo']['name'];
						$file['type']		= $_FILES['photo']['type'];
						$file['tmp_name']= $_FILES['photo']['tmp_name'];
						$file['size']		= $_FILES['photo']['size']; 

						$updateArr = array(
												'name' => $_POST['name'],
												'email' => $_POST['email'],
												'password' => $_POST['password'],
												'gender' => $_POST['gender'],
												'mobile' => $_POST['mobile'],
												'profile_photo' => $file['name'],
												'pid' => $pid
										);
				$files = $this->uploadFile($file['name'], $file['type'], $file['tmp_name'], $file['size']);
				$table = "tx_milkat_domain_model_registration";
				$where = 'uid	= '.$uid;
				$updatess = $this->getDBHandle()->exec_UPDATEquery($table,$where,$updateArr);
				}
				$field = "*";
				$table = "tx_milkat_domain_model_registration";
				if($uid){
						$where = 'uid	= '.$uid;
						//echo $res = $this->getDBHandle()->SELECTquery($field,$table,$where); die;
						$result = $this->getDBHandle()->exec_SELECTgetRows( $field,$table,$where);
						$result = $result[0];
						return $result;

					
				 /*		echo "<pre>";
						print_r($result);
						die;
								 */
				}
		}	 
		public function checkLogin()
		{
						$email = $_REQUEST['username'];
						$password = $_REQUEST['pass'];
						$select_fields = '*';
						$from_table = 'tx_milkat_domain_model_registration';
						$where_clause = "hidden = 0 AND deleted = 0 AND status = 1 AND email = '$email' AND password = '$password'";
						 //echo $log	=	$this->getDBHandle()->SELECTquery($select_fields,$from_table,$where_clause,$groupBy = '',$orderBy = '',$limit = '' ) ; die;
						$log = $this->getDBHandle()->exec_SELECTquery($select_fields, $from_table, $where_clause, $groupBy = '', $orderBy = '', $limit = '');
						$numofraws = $this->getDBHandle()->sql_num_rows($log);
						if ($numofraws == 0) {
								return -1;
						}
						if ($numofraws > 0) {
								
								while ($row = $GLOBALS['TYPO3_DB']->sql_fetch_assoc($log)) {
										$uid = $row['uid'];
										$_SESSION['uid'] = $uid;
							 }
								return 2;
						}
 
		}
		 /**
		 * @param $settings
		 * @param $actionUrl
		 * @param $uid
		 */
		public function getProfile($settings,$actionUrl,$uid){
				$field = "*";
				$table = "tx_milkat_domain_model_registration";
				$where = "hidden = 0 AND deleted = 0 AND uid = ".$uid;
				$profile = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where);
				$profile = $profile[0];
				return $profile;
		}
		/**
		 * @param $settings
		 * @param $actionUrl
		 */
		public function getCategory($settings,$actionUrl){
				$field = "*";
				$table = "tx_milkat_domain_model_category";
				$where = "hidden = 0 AND deleted = 0";
				$category = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where);
				/* foreach($category as $key=>$value){
								//$data[$value['uid']]['name'] = $value['categoryname'];
								$data[]= $value['categoryname'];
								
						}
				return $data;*/
				return $category;
	}
		/**
		 * @param $settings
		 * @param $actionUrl
		 */
		public function getLocation($settings,$actionUrl){
				$field = "*";
				$table = "tx_milkat_domain_model_location";
				$where = "hidden = 0 AND deleted = 0";
				$category = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where);
				return $category;
		}
		/**
		 * @param $settings
		 * @param $actionUrl
		 */
		public function getAmenities($settings,$actionUrl){
				$field = "*";
				$table = "tx_milkat_domain_model_amenities";
				$where = "hidden = 0 AND deleted = 0";
				$category = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where);
				return $category;
		}
		 /**
		 * @param $settings
		 * @param $actionUrl
		 * @param $uid
		 * @param $getmethodsData
		 */
		public function postproperty($settings, $actionUrl ,$uid,$getmethodsData)
		{
		 
				$pid = $settings['registrationstoragePID'];
				$file['name']		= $_FILES['propertyphoto']['name'];
				$file['type']		= $_FILES['propertyphoto']['type'];
				$file['tmp_name']	= $_FILES['propertyphoto']['tmp_name'];
				$file['size']		= $_FILES['propertyphoto']['size'];
			
				$fileStored = $file['name'];
				$mime_type = $file['type'];
				//$propertyImg = implode(',', $file['name']);
				$no_of_propertyImg =	count($fileStored);
				
				$no_of_category =	count($_POST['category']);
				$no_of_location =	count($_POST['location']);
				$no_of_amenities =	count($_POST['amenities']);

				$fields_values = array(
						'milkatname' => $_POST['propertyname'],
						'property_address' => $_POST['property_address'],
						'short_description' => $_POST['short_description'],
						'full_description' => $_POST['full_description'],
						'price' => $_POST['price'],
						'image' => $no_of_propertyImg,
						'ownership' => $_POST['ownership'],
						'possession_from' => $_POST['possession_from'],
						'built_area' => $_POST['built_area'],
						'property_facing' => $_POST['property_facing'],
						'category' => $no_of_category,
						'location' => $no_of_location,
						'amenities' => $no_of_amenities ,
						'registration' => $uid,
						'pid' => $pid
				);
			 /* echo "<pre>";
				print_r($_POST['category']);
				die;*/
			 
					 
				$files = $this->uploadFile($file['name'], $file['type'], $file['tmp_name'], $file['size']);		

				$table = 'tx_milkat_domain_model_milkat';
				$where = 'hidden = 0 AND deleted = 0 ';
				
	 
				//echo $reg	=	$this->getDBHandle()->INSERTquery($table,$fields_values,$no_quote_fields = false ,$where); die;
				$post = $this->getDBHandle()->exec_INSERTquery($table, $fields_values, $no_quote_fields = false, $where);
				if ($post) {
					 $lastInsertId = $this->getDBHandle()->sql_insert_id($post);

					 
					/*for FAL image insert code start */
					 $img_count = 1;
					 foreach ($fileStored as $key => $value) {
							 $sys_file_imgtable = "sys_file";
							 $uploadPath = '/user_upload/postproperty/'.$value;
							 $sys_file_fields_values = array(
									'tstamp' => $GLOBALS['EXEC_TIME'],
									'identifier' => $uploadPath,
									'mime_type' => $_FILES['propertyphoto']['type'][$key],
									'name' => $value
								);
							 $falimag = $this->getDBHandle()->exec_INSERTquery($sys_file_imgtable, $sys_file_fields_values, $no_quote_fields = false);

							 $last_sys_file_InsertId = $this->getDBHandle()->sql_insert_id($falimag);
								$sys_reference_imgtable = "sys_file_reference";
								$Sys_reference_fields_values = array(
										'crdate' => $GLOBALS['EXEC_TIME'],
										'tstamp' => $GLOBALS['EXEC_TIME'],
										'uid_local' => $last_sys_file_InsertId,
										'tablenames' => 'tx_milkat_domain_model_milkat',
										'pid' => $pid ,
										'sorting_foreign' =>$img_count,
										'uid_foreign' => $lastInsertId,
										'fieldname' =>'image',
										'table_local' =>'sys_file'
									);
								$falimag = $this->getDBHandle()->exec_INSERTquery($sys_reference_imgtable, $Sys_reference_fields_values, $no_quote_fields = false);
							$img_count++;
					 }
          
					
					 /*for FAL image insert code END*/

					 /*for category ,location and amenites insert*/
						$cat = $_POST['category'];
						$where = 'hidden = 0 AND deleted = 0 ';
						$cat_count = 1;
						foreach ($cat as $value) {
								$fields = array('uid_local' => $lastInsertId,'uid_foreign' => $value ,'sorting' =>$cat_count );
								$posted = $this->getDBHandle()->exec_INSERTquery('tx_milkat_milkat_category_mm', $fields, $no_quote_fields = false, $where);
								$cat_count++;
						}
						$loc = $_POST['location'];
						$where = 'hidden = 0 AND deleted = 0 ';
						$loc_count = 1;
						foreach ($loc as $value) {
								$fields = array('uid_local' => $lastInsertId,'uid_foreign' => $value ,'sorting' =>$loc_count );
								$posted = $this->getDBHandle()->exec_INSERTquery('tx_milkat_milkat_location_mm', $fields, $no_quote_fields = false, $where);
								$loc_count++;
						}
						$ame = $_POST['amenities'];
						$where = 'hidden = 0 AND deleted = 0 ';
						$ame_count = 1;
						foreach ($ame as $value) {
								$fields = array('uid_local' => $lastInsertId,'uid_foreign' => $value ,'sorting' =>$ame_count );
								$posted = $this->getDBHandle()->exec_INSERTquery('tx_milkat_milkat_amenities_mm', $fields, $no_quote_fields = false, $where);
								$ame_count++;
						}
						 /*for category ,location and amenites insert End*/
						return 7;
				}

		}

		/**
		 * @param $settings
		 * @param $actionUrl
		 * @param $uid
		 * @param $getmethodsData
		 */
		public function getProperty($settings,$actionUrl,$uid,$getmethodsData)
		{
				$propertyID = $getmethodsData['tx_milkat_milkat']['milkat'];
				$field = 'p.*';
				$table = 'tx_milkat_domain_model_milkat AS p 

												LEFT JOIN tx_milkat_milkat_category_mm AS m ON m.uid_local = p.uid 
												LEFT JOIN tx_milkat_domain_model_category AS c ON m.uid_foreign = c.uid';


				if($uid){
						$where = ' p.hidden = 0 AND p.deleted = 0 AND p.registration ='.$uid;
				}else{
				$where = ' p.hidden = 0 AND p.deleted = 0 '; 
				}
				if($propertyID){
						/*
						$field = 'p.*';
						$table = 'tx_milkat_domain_model_milkat AS p 

												LEFT JOIN tx_milkat_milkat_category_mm AS m ON m.uid_local = p.uid 
												LEFT JOIN tx_milkat_domain_model_category AS c ON m.uid_foreign = c.uid';
*/					
						$field = 'p.*,c.uid AS cat_id,c.categoryname,l.uid AS loc_id,l.location_name,a.uid AS amm_id,a.aminities_name';
						$table = 'tx_milkat_domain_model_milkat AS p 
												 LEFT JOIN tx_milkat_milkat_category_mm AS cmm ON cmm.uid_local = p.uid 
														LEFT JOIN tx_milkat_domain_model_category AS c ON cmm.uid_foreign = c.uid

														LEFT JOIN tx_milkat_milkat_location_mm AS lmm ON lmm.uid_local = p.uid 
														LEFT JOIN tx_milkat_domain_model_location AS l ON lmm.uid_foreign = l.uid

														LEFT JOIN tx_milkat_milkat_amenities_mm AS amm ON amm.uid_local = p.uid 
														LEFT JOIN tx_milkat_domain_model_amenities AS a ON amm.uid_foreign = a.uid';
						$where = ' p.hidden = 0 AND p.deleted = 0 AND p.uid ='.$propertyID;
						//$groupBy = ' p.uid ';
						//echo $property	=	$this->getDBHandle()->SELECTquery($field, $table, $where ,$groupBy); die;
						$property = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy);
						$property = $this->FalImage($property, 'tx_milkat_domain_model_milkat');
						
							foreach ($property as $key => $value) {
								
								$cat[$value['cat_id']] = $value['categoryname'];
								//$result[$key]['cat'][][] = $value['categoryname'];
								$loc[$value['loc_id']] = $value['location_name'];
								$ame[$value['amm_id']] = $value['aminities_name'];
								
								}
								$property = $property[0];
								$property['cat'] = $cat;
								$property['loc'] = $loc;
								$property['ame'] = $ame;
							
								return $property;
				}else{
						$groupBy = ' p.uid ';
						//echo $property	=	$this->getDBHandle()->SELECTquery($field, $table, $where ,$groupBy); die;
						$property = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy);
						$property = $this->FalImage($property, 'tx_milkat_domain_model_milkat');
						return $property;
				}										 
								
				$groupBy = ' p.uid ';
				//echo $property	=	$this->getDBHandle()->SELECTquery($field, $table, $where ,$groupBy); die;
				$property = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy);
				$property = $this->FalImage($property, 'tx_milkat_domain_model_milkat');
				return $property;
					
		}
		 /**
		 * @param $settings
		 * @param $actionUrl
		 * @param $getmethodsData
		 */
		public function update_deleteProperty($settings,$actionUrl,$getmethodsData){

				$file['name']		= $_FILES['propertyphoto']['name'];
				$file['type']		= $_FILES['propertyphoto']['type'];
				$file['tmp_name']	= $_FILES['propertyphoto']['tmp_name'];
				$file['size']		= $_FILES['propertyphoto']['size'];
				
				$propertyImg = $file['name'][0];
				
				//$propertyImg = implode(',', $file['name']);
				
				$delid = $getmethodsData['tx_milkat_milkat']['delete'];
				$updid = $getmethodsData['tx_milkat_milkat']['update'];


				$field = "*";
				$table = 'tx_milkat_domain_model_milkat';

				if($delid){
						$where = 'uid	= '.$delid;
						//echo $res = $this->getDBHandle()->SELECTquery($field,$table,$where); die;
						$result = $this->getDBHandle()->exec_SELECTgetRows( $field,$table,$where);
						$result = $result[0];
								if($result['deleted'] == 0){
										$updateArr = array(
												'deleted'		=> 1,
										);
								}	
				}
				if($updid){
						$field = 'p.*,c.uid AS cat_id,c.categoryname,l.uid AS loc_id,l.location_name,a.uid AS amm_id,a.aminities_name';
						$table = 'tx_milkat_domain_model_milkat AS p 

														LEFT JOIN tx_milkat_milkat_category_mm AS cmm ON cmm.uid_local = p.uid 
														LEFT JOIN tx_milkat_domain_model_category AS c ON cmm.uid_foreign = c.uid

														LEFT JOIN tx_milkat_milkat_location_mm AS lmm ON lmm.uid_local = p.uid 
														LEFT JOIN tx_milkat_domain_model_location AS l ON lmm.uid_foreign = l.uid

														LEFT JOIN tx_milkat_milkat_amenities_mm AS amm ON amm.uid_local = p.uid 
														LEFT JOIN tx_milkat_domain_model_amenities AS a ON amm.uid_foreign = a.uid';


						 $pid = $settings['registrationstoragePID'];
				
						$where = 'p.uid	= '.$updid;
						$groupBy = '';
					 // echo $result = $this->getDBHandle()->SELECTquery( $field,$table,$where); die;
						$result = $this->getDBHandle()->exec_SELECTgetRows( $field,$table,$where,$groupBy,'','');

						foreach ($result as $key => $value) {
								//$result[$key]['cat'][][] = $value['categoryname'];
								$cat[$value['cat_id']] = $value['cat_id'];
								$loc[$value['loc_id']] = $value['loc_id'];
								$ame[$value['amm_id']] = $value['amm_id'];
						}
						
						//$cat = array_unique($cat);
						//$loc = array_unique($loc);
						//$ame = array_unique($ame);
						$result = array_unique($result);

						$result = $this->FalImage($result, 'tx_milkat_domain_model_milkat');
				 /*	 echo "<pre>";
						print_r($result);
						die; */	
						$result = $result[0];

						$result['cat'] = $cat;
						$result['loc'] = $loc;
						$result['ame'] = $ame;

						// echo '<pre>';
						// print_r($result);
						// die();

						if(isset($_REQUEST['updateproperty'])){

						$field = "*";
						$table = 'tx_milkat_domain_model_milkat';

						$no_of_category =	count($_POST['category']);
						$no_of_location =	count($_POST['location']);
						$no_of_amenities =	count($_POST['amenities']);

								$where = 'uid	= '.$updid;
								$updateArr = array(
												'milkatname' => $_REQUEST['propertyname'],
												'property_address' => $_REQUEST['property_address'],
												'short_description' => $_REQUEST['short_description'],
												'full_description' => $_REQUEST['full_description'],
												'price' => $_REQUEST['price'],
												'ownership' => $_REQUEST['ownership'],
												'possession_from' => $_REQUEST['possession_from'],
												'built_area' => $_REQUEST['built_area'],
												'property_facing' => $_REQUEST['property_facing'],
												'image' => $propertyImg,
												'category' => $no_of_category,
												'location' => $no_of_location,
												'amenities' => $no_of_amenities,
												'pid' => $pid
								);
								$files = $this->uploadFile($file['name'], $file['type'], $file['tmp_name'], $file['size']);		
							 // echo "<pre>";
							 // print_r($updateArr);
							 // die;
						}else{
								return $result;

						}
				}
			 //echo $update = $this->getDBHandle()->UPDATEquery($table,$where,$updateArr); die;
			 $updatess = $this->getDBHandle()->exec_UPDATEquery($table,$where,$updateArr);
			 $cat = $_POST['category'];
			 if($cat){
				$wheredel = "uid_local =".$updid;

				$delete = $this->getDBHandle()->exec_DELETEquery('tx_milkat_milkat_category_mm',$wheredel);
				if($delete){
						$cat_count = 1;
						foreach ($cat as $value) {
								$fields = array('uid_local' => $updid,'uid_foreign' => $value ,'sorting' =>$cat_count );
								$cate_updated = $this->getDBHandle()->exec_INSERTquery('tx_milkat_milkat_category_mm', $fields, $no_quote_fields = false);
								$cat_count++;
						}
				}
			 }
			 $loc = $_POST['location'];
			 if($loc){
						$wheredel = 'uid_local ='.$updid;
						$delete = $this->getDBHandle()->exec_DELETEquery('tx_milkat_milkat_location_mm',$wheredel);
						if($delete){
								$loc_count = 1;
								foreach ($loc as $value) {
										$fields = array('uid_local' => $updid,'uid_foreign' => $value ,'sorting' =>$loc_count );
										$loc_updeted = $this->getDBHandle()->exec_INSERTquery('tx_milkat_milkat_location_mm',$fields,$no_quote_fields = false);
										$loc_count++;
								}
						}
			 }
			 $ammm = $_POST['amenities'];
			 if($ammm){
						$wheredel = 'uid_local ='.$updid;
						$delete = $this->getDBHandle()->exec_DELETEquery('tx_milkat_milkat_amenities_mm',$wheredel);
						if($delete){
								$ammm_count = 1;
								foreach ($ammm as $value) {
										$fields = array('uid_local' => $updid,'uid_foreign' => $value ,'sorting' =>$ammm_count );
										$ammm_updated = $this->getDBHandle()->exec_INSERTquery('tx_milkat_milkat_amenities_mm',$fields,$no_quote_fields = false);
										$ammm_count++;
								}
						}
			 }
			 
			 if($updatess){
				return 5;
			 }


		}
		/**
		* uploadFile
		* @param $name
		* @param $type
		* @param $temp
		* @param $size
		* @return
		*/

		protected function uploadFile($name, $type, $temp, $size) {

				if($size > 0) {
						$basicFileFunctions = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('t3lib_basicFileFunctions');
						$uploadPath = 'fileadmin/user_upload/postproperty';
					 // upload folder path

						foreach ($name as $key => $value) {
						
								$valueofimg = $basicFileFunctions->cleanFileName($value);
								$uploadPath = \TYPO3\CMS\Core\Utility\PathUtility::getCanonicalPath($uploadPath);
								$uniqueFileName = $basicFileFunctions->getUniqueName($valueofimg, $uploadPath);
								
								$movetouploded = move_uploaded_file($temp[$key], $uniqueFileName);
						
								//echo $uploadPath = $basicFileFunctions->getCanonicalPath($uploadPath);
								$returnValue = basename($uniqueFileName);
						}
						
				}
						return $returnValue;

		}
		// For image
		/**
		 * @param $result
		 * @param $tablename
		 * @param $fieldname
		 */
		public function FalImage($result, $tablename = NULL, $fieldname = NULL)
		{
				//	 echo "<pre>";
				//	 print_r($result);
				//	 die;
				$where = '';
				if ($tablename != '') {
						$where = ' AND tablenames = "' . $tablename . '"';
				}
				if ($fieldname != '') {
						$where .= ' AND fieldname IN (' . $fieldname . ')';
				}
				foreach ($result as $key => $value) {	 
					
						$whr = 'deleted= 0 and hidden = 0 ' . $where . ' AND uid_foreign = ' . $value['uid'];
						//echo $sysimages = $GLOBALS['TYPO3_DB']->SELECTquery('*', 'sys_file_reference', $whr, '', 'sorting_foreign');	die();
						$sysimages = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('*', 'sys_file_reference', $whr, '', 'sorting_foreign');

						$arr = '';
						foreach ($sysimages as $key1 => $value1) {
								$whr1 = ' uid = ' . $value1['uid_local'];
								//echo $sysimagedetail = $GLOBALS['TYPO3_DB']->SELECTquery('*', 'sys_file', $whr1);	die();
								$sysimagedetail = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('*', 'sys_file', $whr1);
						
								$arr[$value1['fieldname']][$value1['uid']]['imagepath'] = 'fileadmin'.$sysimagedetail[0]['identifier'];
								$arr[$value1['fieldname']][$value1['uid']]['title'] = $value1['title'];
								$arr[$value1['fieldname']][$value1['uid']]['caption'] = $value1['description'];
						}
						$result[$key]['pictures'] = $arr;
				}
				// echo "<pre>";
				// print_r($result);
				// die;
				return $result;
		}
				function sendEmails($recipient,$sender_email,$subject,$mailcontent,$mailName){
						$mail = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Mail\\MailMessage');
						$mail->setFrom($sender_email);													
						$mail->setFrom(array($sender_email => $mailName));							
						$mail->setTo($recipient);
						$mail->setSubject($subject);
						$mail->setBody($mailcontent, 'text/html');
						return $mail->send();

				}
		/**
		 * getDBHandle
		 *
		 * @return
		 */
		public function getDBHandle()
		{
				return $GLOBALS['TYPO3_DB'];
		}

}