<?php
namespace Maunil\Milkat\Domain\Repository;

session_start();
/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 maunil <montu1555@gmail.com>, woi
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Registrations
 */
class RegistrationRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{

    /**
     * @param $settings
     * @param $actionUrl
     */
    public function UserRegistration($settings, $actionUrl)
    {
        if (isset($_POST['regist'])) {
            if (isset($_POST['email'])) {
                $pid = $settings['storagePID'];
                $email = $_POST['email'];
                $fields = '*';
                $table = 'tx_milkat_domain_model_registration';
                $where = 'deleted = 0 AND hidden = 0 AND email = "' . $_POST['email'] . '" ';
                $res = $GLOBALS['TYPO3_DB']->exec_SELECTquery($fields, $table, $where);
                $numofraws = $GLOBALS['TYPO3_DB']->sql_num_rows($res);
                if ($numofraws == 0) {
                    if (isset($_FILES['photo'])) {
                        $errors = array();
                        $file_name = $_FILES['photo']['name'];
                        $file_size = $_FILES['photo']['size'];
                        $file_tmp = $_FILES['photo']['tmp_name'];
                        if (!is_dir('typo3conf/ext/milkat/Resources/Public/Images')) {
                            mkdir('typo3conf/ext/milkat/Resources/Public/Images/', 493);
                        }
                        $file_type = $_FILES['photo']['type'];
                        $file_ext = strtolower(end(explode('.', $file_name)));
                        $time = time();
                        $file_name = "{$time}" . "{$file_name}";
                        $expensions = array('jpeg', 'jpg', 'png');
                        if (in_array($file_ext, $expensions) === false) {
                            $errors[] = 'extension not allowed, please choose a JPEG or PNG file.';
                        }
                        if ($file_size > 100000) {
                            $errors[] = 'File size must be excately 2 MB';
                        }
                        if (empty($errors) == true) {
                            move_uploaded_file($file_tmp, 'typo3conf/ext/milkat/Resources/Public/Images/' . $file_name);
                        } else {
                            die;
                        }
                    }
                    $fields_values = array(
                        'name' => $_POST['name'],
                        'email' => $_POST['email'],
                        'password' => $_POST['password'],
                        'gender' => $_POST['gender'],
                        'mobile' => $_POST['mobile'],
                        'profile_photo' => $file_name
                    );
                    $table = 'tx_milkat_domain_model_registration';
                    $where = 'hidden = 0 AND deleted = 0 AND pid =' . $pid;
                    //echo $reg  =  $this->getDBHandle()->INSERTquery($table,$fields_values,$no_quote_fields = false ,$where); die;
                    $reg = $this->getDBHandle()->exec_INSERTquery($table, $fields_values, $no_quote_fields = false, $where);
                    if ($reg) {
                        return 1;
                    }
                }
                if ($numofraws > 0) {
                    return -2;
                }
            }
        }
    }
    
    public function checkLogin()
    {
        $email = $_REQUEST['username'];
        $password = $_REQUEST['pass'];
        echo $_SESSION['username'] = $email;
        $select_fields = '*';
        $from_table = 'tx_milkat_domain_model_registration';
        $where_clause = "hidden = 0 AND deleted = 0 AND email = '{$email}' AND password = '{$password}'";
        // echo $log  =  $this->getDBHandle()->SELECTquery($select_fields,$from_table,$where_clause,$groupBy = '',$orderBy = '',$limit = '' ) ; die;
        $log = $this->getDBHandle()->exec_SELECTquery($select_fields, $from_table, $where_clause, $groupBy = '', $orderBy = '', $limit = '');
        $numofraws = $this->getDBHandle()->sql_num_rows($log);
        if ($numofraws == 0) {
            return -1;
        }
        if ($numofraws > 0) {
            return 2;
        }
    }
    
    /**
     * @param $settings
     * @param $actionUrl
     */
    public function postproperty($settings, $actionUrl)
    {
        // $pid = $settings['storagePID'];
        $fields_values = array(
            'milkatname' => $_POST['propertyname'],
            'property_address' => $_POST['property_address'],
            'short_description' => $_POST['short_description'],
            'full_description' => $_POST['full_description'],
            'price' => $_POST['price'],
            'image' => $_FILES['propertyphoto']['name'],
            'ownership' => $_POST['ownership'],
            'possession_from' => $_POST['possession_from'],
            'built_area' => $_POST['built_area'],
            'property_facing' => $_POST['property_facing'],
            'category' => $_POST['category'],
            'location' => $_POST['location'],
            'amenities' => $_POST['amenities']
        );
        $table = 'tx_milkat_domain_model_milkat';
        $where = 'hidden = 0 AND deleted = 0';
        //echo $reg  =  $this->getDBHandle()->INSERTquery($table,$fields_values,$no_quote_fields = false ,$where); die;
        $post = $this->getDBHandle()->exec_INSERTquery($table, $fields_values, $no_quote_fields = false, $where);
        if ($post) {
            return 7;
        }
    }
    
    public function getProperty()
    {
        $field = 'p.*';
        $table = 'tx_milkat_domain_model_milkat AS p 

		                    LEFT JOIN tx_milkat_milkat_category_mm AS m ON m.uid_local = p.uid 
		                    LEFT JOIN tx_milkat_domain_model_category AS c ON m.uid_foreign = c.uid';
        $where = ' p.hidden = 0 AND p.deleted = 0 ';
        /*if(isset($sid)){
          $where = " p.hidden = 0 AND p.deleted = 0  AND .uid = ".$sid;
          }else{
          if(isset($produktid)){
          $wh = " AND p.uid = ".$produktid;
          }
          $where = " p.hidden = 0 AND p.deleted = 0 ".$wh;
          }*/
        
        $groupBy = ' p.uid ';
        //echo $property  =  $this->getDBHandle()->SELECTquery($field, $table, $where ,$groupBy); die;
        $property = $this->getDBHandle()->exec_SELECTgetRows($field, $table, $where, $groupBy);
        $property = $this->FalImage($property, 'tx_milkat_domain_model_milkat');
        // echo "<pre>";
        // print_r($property);
        // die;
        // foreach ($property as $key => $value) {
        // }
        return $property;
    }
    
    // For image
    /**
     * @param $result
     * @param $tablename
     * @param $fieldname
     */
    public function FalImage($result, $tablename = NULL, $fieldname = NULL)
    {
        //   echo "<pre>";
        //   print_r($result);
        //   die;
        $where = '';
        if ($tablename != '') {
            $where = ' AND tablenames = "' . $tablename . '"';
        }
        if ($fieldname != '') {
            $where .= ' AND fieldname IN (' . $fieldname . ')';
        }
        foreach ($result as $key => $value) {
            //  echo "<pre>";
            // print_r($value);
            // die;
            $whr = 'deleted= 0 and hidden = 0 ' . $where . ' AND uid_foreign = ' . $value['uid'];
            //echo $sysimages = $GLOBALS['TYPO3_DB']->SELECTquery('*', 'sys_file_reference', $whr, '', 'sorting_foreign');  die();
            $sysimages = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('*', 'sys_file_reference', $whr, '', 'sorting_foreign');
            $arr = '';
            foreach ($sysimages as $key1 => $value1) {
                $whr1 = ' uid = ' . $value1['uid_local'];
                $sysimagedetail = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('*', 'sys_file', $whr1);
                $arr[$value1['fieldname']][$value1['uid']]['imagepath'] = 'fileadmin' . $sysimagedetail[0]['identifier'];
                $arr[$value1['fieldname']][$value1['uid']]['title'] = $value1['title'];
                $arr[$value1['fieldname']][$value1['uid']]['caption'] = $value1['description'];
            }
            $result[$key]['pictures'] = $arr;
        }
        // echo "<pre>";
        // print_r($result);
        // die;
        return $result;
    }
    
    /**
     * getDBHandle
     *
     * @return
     */
    public function getDBHandle()
    {
        return $GLOBALS['TYPO3_DB'];
    }

}