﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _changelog:

ChangeLog
=========

Providing a change log chapter is optional. You can also refer
users to the ChangeLog file inside the extension or to some repository's
commit listing.
