$(document).ready(function(){
		$('.row').each(function(){
		var highestBox = 0;
		$('.desc-content', this).each(function(){
			if($(this).height() > highestBox)
				highestBox = $(this).height();
			});
		$('.desc-content',this).height(highestBox);
	});

		$('.row').each(function(){
		var highestBox = 0;
		$('.city-content', this).each(function(){
			if($(this).height() > highestBox)
				highestBox = $(this).height();
			});
		$('.city-content',this).height(highestBox);
	});

});

jQuery(function(){
	jQuery(".event-grid .btn-event").click(function(){
		jQuery(".event-grid .btn-event").removeClass('btn-default').addClass('btn-small');
		jQuery(this).addClass('btn-default').removeClass('btn-small');
		var _data_target = jQuery(this).attr('data-tg');			
		if(_data_target == 'all'){
			jQuery(".event-list").fadeIn();
		}else{
			jQuery(".event-list").fadeOut();
		}	
		jQuery(".event-list").each(function(){
			var _data_tar = jQuery(this).attr('data-show');
			if(_data_tar.indexOf(_data_target) != -1){
			   jQuery(this).fadeIn();
			}
		});
	});
});

function reloadForm() {
		$('#submit_btn').trigger('click');
	return true;
}

$(function(){
      SyntaxHighlighter.all();
    });
    $(window).load(function(){
      $('#carousel').flexslider({
        animation: "slide",
        controlNav: false,
        animationLoop: false,
        slideshow: false,
        itemWidth: 210,
        itemMargin: 5,
        asNavFor: '#slider'
      });

      $('#slider').flexslider({
        animation: "slide",
        controlNav: false,
        animationLoop: false,
        slideshow: false,
        sync: "#carousel",
        start: function(slider){
          $('body').removeClass('loading');
        }
      });
    });