<?php
namespace Woi\Event\Controller;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Deepak <Deepakvisani@gmail.com>, Woi
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * EventController
 */
class EventController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * eventRepository
	 *
	 * @var \Woi\Event\Domain\Repository\EventRepository
	 * @inject
	 */
	protected $eventRepository = NULL;

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {
		$events = $this->eventRepository->event(0, $this->settings);
		$categories = $this->eventRepository->categoryName();
		$city = $this->eventRepository->getCity();
		
		if (isset($this->settings['storagePID'])) {
			$storage = $this->settings['storagePID'];
		}

		if (isset($_GET['city'])) {
			$selected = $_GET['city'];
		}


		/*echo '<pre>';
		print_r($_GET);
		echo '</pre>';
		die();*/

		$this->view->assign('setting', $this->settings);
		$this->view->assign('events', $events);
		$this->view->assign('categoryname', $categories);
		$this->view->assign('city', $city);
		$this->view->assign('selected', $selected);
		$this->includeAdditionalData();
	}

	/**
	 * action show
	 *
	 * @param \Woi\Event\Domain\Model\Event $event
	 * @return void
	 */
	public function showAction() {
		//$this->view->assign('event', $event);
		$GLOBALS['TSFE']->set_no_cache();
		$uriArr = \TYPO3\CMS\Core\Utility\GeneralUtility::_GP('tx_event_event');
		$eventid = 0;
		if (isset($uriArr['event']) && $uriArr['event'] > 0) {
			$eventid = $uriArr['event'];
		}
		$events = $this->eventRepository->event($eventid, $this->settings);
		$this->view->assign('eventdetail', $events);
		$this->includeAdditionalData();
	}

	/**
	 * includeAdditionalData
	 *
	 * @return
	 */
	function includeAdditionalData() {
		$additionalfooterData = '
		<script src="typo3conf/ext/event/Resources/Public/javascript/event.js" type="text/javascript"></script>
		<script src="typo3conf/ext/event/Resources/Public/javascript/jquery.flexslider.js" type="text/javascript"></script>';
		$additionalheaderData .= '
	<link rel="stylesheet" href="typo3conf/ext/event/Resources/Public/css/event.css" type="text/css" media="all" />
	<link rel="stylesheet" href="typo3conf/ext/event/Resources/Public/css/font-awesome.min.css" type="text/css" media="all" />
	<link rel="stylesheet" href="typo3conf/ext/event/Resources/Public/css/flexslider.css" type="text/css" media="all" />
	
		';
		$GLOBALS['TSFE']->additionalFooterData['9996'] = $additionalfooterData;
		$GLOBALS['TSFE']->additionalHeaderData['9669'] = $additionalheaderData;
	}

}