<?php
namespace JS\JsProduct\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Product
 */
class Product extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * title
     *
     * @var string
     */
    protected $title = '';
    
    /**
     * shortDescription
     *
     * @var string
     */
    protected $shortDescription = '';
    
    /**
     * description
     *
     * @var string
     */
    protected $description = '';
    
    /**
     * description1
     *
     * @var string
     */
    protected $description1 = '';
    
    /**
     * image
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    protected $image = NULL;
    
    /**
     * gallery
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     */
    protected $gallery = NULL;
    
    /**
     * link
     *
     * @var string
     */
    protected $link = '';
    
    /**
     * subCategory
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsProduct\Domain\Model\SubCategory>
     */
    protected $subCategory = NULL;
    
    /**
     * price
     *
     * @var string
     */
    protected $price = '';
    
    /**
     * specification
     *
     * @var string
     */
    protected $specification = '';
    
    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }
    
    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->subCategory = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }
    
    /**
     * Returns the title
     *
     * @return string title
     */
    public function getTitle()
    {
        return $this->title;
    }
    
    /**
     * Sets the title
     *
     * @param string $title
     * @return string title
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }
    
    /**
     * Returns the shortDescription
     *
     * @return string shortDescription
     */
    public function getShortDescription()
    {
        return $this->shortDescription;
    }
    
    /**
     * Sets the shortDescription
     *
     * @param string $shortDescription
     * @return string shortDescription
     */
    public function setShortDescription($shortDescription)
    {
        $this->shortDescription = $shortDescription;
    }
    
    /**
     * Returns the description
     *
     * @return string description
     */
    public function getDescription()
    {
        return $this->description;
    }
    
    /**
     * Sets the description
     *
     * @param string $description
     * @return string description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }
    
    /**
     * Returns the description1
     *
     * @return string description1
     */
    public function getDescription1()
    {
        return $this->description1;
    }
    
    /**
     * Sets the description1
     *
     * @param string $description1
     * @return string description1
     */
    public function setDescription1($description1)
    {
        $this->description1 = $description1;
    }
    
    /**
     * Returns the link
     *
     * @return string link
     */
    public function getLink()
    {
        return $this->link;
    }
    
    /**
     * Sets the link
     *
     * @param string $link
     * @return string link
     */
    public function setLink($link)
    {
        $this->link = $link;
    }
    
    /**
     * Adds a SubCategory
     *
     * @param \JS\JsProduct\Domain\Model\SubCategory $subCategory
     * @return void
     */
    public function addSubCategory(\JS\JsProduct\Domain\Model\SubCategory $subCategory)
    {
        $this->subCategory->attach($subCategory);
    }
    
    /**
     * Removes a SubCategory
     *
     * @param \JS\JsProduct\Domain\Model\SubCategory $subCategoryToRemove The SubCategory to be removed
     * @return void
     */
    public function removeSubCategory(\JS\JsProduct\Domain\Model\SubCategory $subCategoryToRemove)
    {
        $this->subCategory->detach($subCategoryToRemove);
    }
    
    /**
     * Returns the subCategory
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsProduct\Domain\Model\SubCategory> $subCategory
     */
    public function getSubCategory()
    {
        return $this->subCategory;
    }
    
    /**
     * Sets the subCategory
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\JS\JsProduct\Domain\Model\SubCategory> $subCategory
     * @return void
     */
    public function setSubCategory(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $subCategory)
    {
        $this->subCategory = $subCategory;
    }
    
    /**
     * Returns the image
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference image
     */
    public function getImage()
    {
        return $this->image;
    }
    
    /**
     * Sets the image
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference image
     */
    public function setImage(\TYPO3\CMS\Extbase\Domain\Model\FileReference $image)
    {
        $this->image = $image;
    }
    
    /**
     * Returns the gallery
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $gallery
     */
    public function getGallery()
    {
        return $this->gallery;
    }
    
    /**
     * Sets the gallery
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $gallery
     * @return void
     */
    public function setGallery(\TYPO3\CMS\Extbase\Domain\Model\FileReference $gallery)
    {
        $this->gallery = $gallery;
    }
    
    /**
     * Returns the price
     *
     * @return string $price
     */
    public function getPrice()
    {
        return $this->price;
    }
    
    /**
     * Sets the price
     *
     * @param string $price
     * @return void
     */
    public function setPrice($price)
    {
        $this->price = $price;
    }
    
    /**
     * Returns the specification
     *
     * @return string $specification
     */
    public function getSpecification()
    {
        return $this->specification;
    }
    
    /**
     * Sets the specification
     *
     * @param string $specification
     * @return void
     */
    public function setSpecification($specification)
    {
        $this->specification = $specification;
    }

}