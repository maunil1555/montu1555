<?php
namespace JS\JsProduct\Controller;

session_start();

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * ProductController
 */
class ProductController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

	/**
	 * productRepository
	 *
	 * @var \JS\JsProduct\Domain\Repository\ProductRepository
	 * @inject
	 */
	protected $productRepository = NULL;
		
	/**
	 * action product
	 *
	 * @return void
	 */
	public function productAction()
	{
		$GLOBALS['TSFE']->set_no_cache();

        if (isset($_GET['tx_jsproduct_product']['subcategory'])) {
            $sid = $_GET['tx_jsproduct_product']['subcategory'];
        }

        if (isset($_GET['tx_jsproduct_product']['product'])) {
            $pid = $_GET['tx_jsproduct_product']['product'];
        }

        $product = $this->productRepository->product($this->settings, $pid, $sid);

        $template = $js = "";

        if($pid>0){
            $template = "detail";
            $js = '<script>
            			jssor_1_slider_init();
					</script>';
        }

        if (isset($_POST['tx_powermail_pi1']['field'])) {
 			$template = "detail";
        }

        $subCategory = $this->productRepository->getSubCategory($this->settings, $sid);

        $this->view->assign('subCategories', $subCategory);

        $this->view->assign('template', $template);


        
        $this->view->assign('products', $product);

        $GLOBALS['TSFE']->additionalHeaderData['product'] = '<link rel="stylesheet" href="typo3conf/ext/js_product/Resources/Public/Css/internal.css" type="text/css" media="all" /><link rel="stylesheet" href="typo3conf/ext/js_product/Resources/Public/Css/bootstrap.css"><link rel="stylesheet" href="typo3conf/ext/js_product/Resources/Public/Css/product.css" type="text/css" media="all" />';

		$GLOBALS['TSFE']->additionalFooterData['product1'] = '
		<script src="typo3conf/ext/js_product/Resources/Public/Js/jquery-1.11.3.min.js" type="text/javascript"></script>
		<script src="typo3conf/ext/js_product/Resources/Public/Js/product.js" type="text/javascript"></script>
		<script src="typo3conf/ext/js_product/Resources/Public/Js/jssor.slider.min.js" type="text/javascript"></script>
		<script src="typo3conf/ext/js_product/Resources/Public/Js/jssor.slider.debug.js" type="text/javascript"></script>
		<script src="typo3conf/ext/js_product/Resources/Public/Js/internal.js" type="text/javascript"></script>
		<script src="typo3conf/ext/js_product/Resources/Public/Js/bootstrap.min.js"></script>'.$js;



	}
	
	/**
	 * action category
	 *
	 * @return void
	 */
	public function categoryAction()
	{
		$GLOBALS['TSFE']->set_no_cache();

        if (isset($_GET['tx_jsproduct_category']['view'])) {
            $_SESSION['view'] = $_GET['tx_jsproduct_category']['view'];

			$pageUid = $GLOBALS['TSFE']->id;
			$baseUri = $this->request->getBaseUri();
			
			$url = $this->request->getBaseUri().'index.php?id='.$pageUid; 
			
			header('Location:' . $url); die;
        }
		
		if(isset($_SESSION['view'])){
			$this->settings['forceMode'] = $_SESSION['view'];	
		}

		$category = $this->productRepository->getCategory($this->settings);

		$subCategory = $this->productRepository->getSubCategory($this->settings);

		$this->view->assign('category', $category);
		$this->view->assign('subCategories', $subCategory);
		$this->view->assign('settings', $this->settings);
		
		$GLOBALS['TSFE']->additionalFooterData['team'] = '<link rel="stylesheet" href="typo3conf/ext/js_product/Resources/Public/Css/product.css" type="text/css" media="all" /><script src="typo3conf/ext/js_product/Resources/Public/Js/product.js" type="text/javascript"></script>';	   
	}

}