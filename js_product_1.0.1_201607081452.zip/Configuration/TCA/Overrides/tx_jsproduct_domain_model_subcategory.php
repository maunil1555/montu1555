<?php 
## EXTENSION BUILDER DEFAULTS END TOKEN - Everything BEFORE this line is overwritten with the defaults of the extension builder

$GLOBALS['TCA']['tx_jsproduct_domain_model_subcategory']['columns']['category']['config']['foreign_table_where'] =
 ' AND tx_jsproduct_domain_model_category.sys_language_uid IN (-1,0)';
 